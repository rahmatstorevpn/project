#!/bin/bash

CONFIG_FILE="/etc/zivpn/config.json"
USER_DB="/etc/zivpn/users.json"
LOG_FILE="/var/log/zivpn.log"
BACKUP_DIR="/etc/zivpn/backups"
SERVICE="zivpn"

# Konfigurasi Backup
BACKUP_CONFIG="/etc/zivpn/backup_config.json"

# Konfigurasi GitHub
GITHUB_TOKEN="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"
GITHUB_USERNAME="rahmatstorevpn"
GITHUB_REPO="project"
GITHUB_BACKUP_DIR="zivpn_backups"

# Warna untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'
BG_BLUE='\033[44m'
BG_GREEN='\033[42m'
BG_YELLOW='\033[43m'
BG_RED='\033[41m'
BG_PURPLE='\033[45m'

# ==============================
# FUNGSI UTAMA YANG SUDAH ADA
# ==============================

# Fungsi untuk mendapatkan IP server
get_server_ip() {
    if command -v curl &>/dev/null; then
        ip=$(curl -s https://api.ipify.org)
    elif command -v wget &>/dev/null; then
        ip=$(wget -qO- https://api.ipify.org)
    else
        ip=$(hostname -I | awk '{print $1}')
    fi
    echo "$ip"
}

# Fungsi untuk tampilan header
show_header() {
    clear
    echo -e "${BG_BLUE}${BOLD}════════════════════════════════════════════════════════════${NC}"
    echo -e "${BG_BLUE}${BOLD}             ZIVPN MANAGER - BISNIS VPN                    ${NC}"
    echo -e "${BG_BLUE}${BOLD}════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# Fungsi untuk backup config
backup_config() {
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    cp "$CONFIG_FILE" "${CONFIG_FILE}.backup_${timestamp}"
    echo -e "${YELLOW}Backup created: ${CONFIG_FILE}.backup_${timestamp}${NC}" >> "$LOG_FILE"
}

# Fungsi inisialisasi database user
init_user_db() {
    if [ ! -f "$USER_DB" ]; then
        echo -e "${YELLOW}Creating user database...${NC}"
        cat > "$USER_DB" << EOF
{
    "users": {},
    "settings": {
        "max_devices_per_user": 3,
        "auto_cleanup_days": 7
    }
}
EOF
        echo -e "${GREEN}✓ User database created${NC}"
    fi
}

# Fungsi untuk memastikan struktur config.json benar
ensure_config_structure() {
    if [ ! -f "$CONFIG_FILE" ]; then
        echo -e "${YELLOW}Creating new config file...${NC}"
        cat > "$CONFIG_FILE" << EOF
{
    "listen": ":5667",
    "cert": "/etc/zivpn/zivpn.crt",
    "key": "/etc/zivpn/zivpn.key",
    "obfs": "zivpn",
    "auth": {
        "mode": "passwords",
        "config": []
    }
}
EOF
        echo -e "${GREEN}✓ Config file created${NC}"
    fi
}

# Install dependensi
install_dependencies() {
    if ! command -v jq &>/dev/null; then
        echo -e "${YELLOW}Installing jq...${NC}"
        apt-get update && apt-get install -y jq
        echo -e "${GREEN}✓ jq berhasil diinstall${NC}"
    fi
    
    if ! command -v bc &>/dev/null; then
        echo -e "${YELLOW}Installing bc...${NC}"
        apt-get install -y bc
        echo -e "${GREEN}✓ bc berhasil diinstall${NC}"
    fi
    
    if ! command -v curl &>/dev/null; then
        echo -e "${YELLOW}Installing curl...${NC}"
        apt-get install -y curl
        echo -e "${GREEN}✓ curl berhasil diinstall${NC}"
    fi
    
    if ! command -v git &>/dev/null; then
        echo -e "${YELLOW}Installing git...${NC}"
        apt-get install -y git
        echo -e "${GREEN}✓ git berhasil diinstall${NC}"
    fi
}

# Restart service
restart_service() {
    echo -e "\n${YELLOW}Merestart service $SERVICE...${NC}"
    systemctl restart $SERVICE
    if systemctl is-active --quiet $SERVICE; then
        echo -e "${GREEN}✓ Service $SERVICE berhasil direstart${NC}"
        return 0
    else
        echo -e "${RED}❌ Gagal restart service $SERVICE${NC}"
        return 1
    fi
}

# Fungsi untuk cek masa aktif
check_expiry() {
    local username=$1
    local expiry_date=$(jq -r ".users.\"$username\".expiry_date" "$USER_DB" 2>/dev/null)
    
    if [ -z "$expiry_date" ] || [ "$expiry_date" = "null" ]; then
        echo "no_expiry"
        return
    fi
    
    if [ "$expiry_date" = "unlimited" ]; then
        echo "no_expiry"
        return
    fi
    
    local current_date=$(date +%s)
    local expiry_seconds=$(date -d "$expiry_date" +%s 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        echo "invalid_date"
        return
    fi
    
    if [ "$current_date" -gt "$expiry_seconds" ]; then
        echo "expired"
    else
        local days_left=$(( (expiry_seconds - current_date) / 86400 ))
        echo "$days_left"
    fi
}

# Fungsi untuk auto hapus user expired
auto_cleanup_expired() {
    echo -e "${YELLOW}🔄 Running auto cleanup for expired users...${NC}"
    local count=0
    
    # Get all users
    jq -r '.users | keys[]' "$USER_DB" 2>/dev/null | while read username; do
        status=$(check_expiry "$username")
        
        if [ "$status" = "expired" ]; then
            echo -e "${RED}Deleting expired user: $username${NC}"
            
            # Remove password from config
            local password=$(jq -r ".users.\"$username\".password" "$USER_DB")
            jq "del(.auth.config[] | select(. == \"$password\"))" "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"
            
            # Remove from user DB
            jq "del(.users.\"$username\")" "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
            
            ((count++))
            echo "$(date): User $username expired and deleted" >> "$LOG_FILE"
        fi
    done
    
    if [ $count -gt 0 ]; then
        restart_service
        echo -e "${GREEN}✓ Cleaned up $count expired users${NC}"
    else
        echo -e "${GREEN}✓ No expired users found${NC}"
    fi
}

# Fungsi untuk cek login user
check_user_login() {
    show_header
    echo -e "${CYAN}${BOLD}👥 CEK USER LOGIN${NC}\n"
    
    # Cek apakah ada user
    user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
    
    if [ "$user_count" -eq 0 ]; then
        echo -e "${YELLOW}Belum ada user terdaftar${NC}"
        echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
        read
        return
    fi
    
    echo -e "${BG_PURPLE}${BOLD}   DAFTAR USER AKTIF   ${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    # Simulasi cek login (dalam implementasi nyata, ini akan baca dari log ZIVPN)
    echo -e "${YELLOW}⚠️  Fitur ini memerlukan integrasi dengan log ZIVPN${NC}"
    echo -e "${YELLOW}Untuk implementasi nyata, perlu membaca dari:${NC}"
    echo -e "${CYAN}/var/log/zivpn/connection.log${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}\n"
    
    # Tampilkan semua user dengan status
    echo -e "${CYAN}${BOLD}User yang terdaftar:${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    printf "%-20s %-15s %-12s %-10s\n" "Username" "Expiry" "Status" "Devices"
    echo -e "${BOLD}────────────────────────────────────────────────────────${NC}"
    
    jq -r '.users | to_entries[] | "\(.key)|\(.value.expiry_date)|\(.value.device_count // 0)"' "$USER_DB" 2>/dev/null | while IFS='|' read username expiry device_count; do
        status=$(check_expiry "$username")
        
        if [ "$status" = "expired" ]; then
            status_text="${RED}EXPIRED${NC}"
            expiry_text="${RED}$expiry${NC}"
        elif [ "$status" = "no_expiry" ]; then
            status_text="${GREEN}ACTIVE${NC}"
            expiry_text="${GREEN}Unlimited${NC}"
        elif [[ "$status" =~ ^[0-9]+$ ]]; then
            status_text="${GREEN}ACTIVE${NC}"
            expiry_text="${GREEN}$status days${NC}"
        else
            status_text="${YELLOW}$status${NC}"
            expiry_text="${YELLOW}$expiry${NC}"
        fi
        
        printf "%-20s %-15s %-30s %-10s\n" "$username" "$(echo -e "$expiry_text")" "$(echo -e "$status_text")" "$device_count"
    done
    
    echo -e "\n${YELLOW}📊 Statistik:${NC}"
    echo -e "${BOLD}────────────────────────────────────${NC}"
    echo -e "${CYAN}Total User     : ${GREEN}$user_count${NC}"
    echo -e "${CYAN}Max Devices    : ${GREEN}$(jq -r '.settings.max_devices_per_user' "$USER_DB" 2>/dev/null || echo "3")${NC}"
    echo -e "${BOLD}────────────────────────────────────${NC}"
    
    echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
    read
}

# Hapus user
delete_user() {
    while true; do
        show_header
        echo -e "${RED}${BOLD}🗑️  HAPUS USER${NC}\n"
        
        # Cek apakah ada user
        user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "${YELLOW}Tidak ada user yang terdaftar${NC}"
            sleep 2
            return
        fi
        
        echo -e "${CYAN}Daftar User:${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        jq -r '.users | to_entries[] | "\(.key)|\(.value.expiry_date)"' "$USER_DB" 2>/dev/null | while IFS='|' read username expiry; do
            status=$(check_expiry "$username")
            if [ "$status" = "expired" ]; then
                echo -e "${RED}• $username (EXPIRED)${NC}"
            elif [ "$status" = "no_expiry" ]; then
                echo -e "${GREEN}• $username (ACTIVE)${NC}"
            elif [[ "$status" =~ ^[0-9]+$ ]]; then
                echo -e "${GREEN}• $username ($status hari lagi)${NC}"
            else
                echo -e "${YELLOW}• $username${NC}"
            fi
        done
        
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}\n"
        
        read -p "$(echo -e ${YELLOW}"Masukkan username yang ingin dihapus (atau 'q' untuk kembali): "${NC})" username
        
        if [ "$username" = "q" ] || [ "$username" = "Q" ]; then
            return
        fi
        
        # Cek apakah username ada
        if ! jq -e ".users.\"$username\"" "$USER_DB" >/dev/null 2>&1; then
            echo -e "\n${RED}❌ Username '$username' tidak ditemukan!${NC}"
            sleep 2
            continue
        fi
        
        # Dapatkan password user
        password=$(jq -r ".users.\"$username\".password" "$USER_DB")
        
        echo -e "\n${YELLOW}⚠️  Konfirmasi Penghapusan${NC}"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        echo -e "${RED}User yang akan dihapus:${NC}"
        echo -e "${RED}Username: ${BOLD}$username${NC}"
        echo -e "${RED}Password: ${BOLD}$password${NC}"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        
        read -p "$(echo -e ${YELLOW}"Yakin ingin menghapus? (y/n): "${NC})" confirm
        
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            echo -e "${YELLOW}Penghapusan dibatalkan${NC}"
            sleep 1
            continue
        fi

        # Backup sebelum modifikasi
        backup_config
        
        # Hapus password dari config
        jq "del(.auth.config[] | select(. == \"$password\"))" "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"
        
        # Hapus dari database user
        jq "del(.users.\"$username\")" "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
        
        echo -e "\n${GREEN}✓ User '$username' berhasil dihapus!${NC}"
        
        # Restart service
        restart_service
        
        echo -e "\n${YELLOW}📋 Total user tersisa: ${GREEN}$(jq '.users | length' "$USER_DB")${NC}"
        
        read -p "$(echo -e ${YELLOW}"Hapus user lagi? (y/n): "${NC})" delete_more
        if [[ ! "$delete_more" =~ ^[Yy]$ ]]; then
            break
        fi
    done
}

# ==============================
# FUNGSI BACKUP & RESTORE (GITHUB)
# ==============================

# Fungsi untuk inisialisasi konfigurasi backup
init_backup_config() {
    if [ ! -f "$BACKUP_CONFIG" ]; then
        echo -e "${YELLOW}Membuat konfigurasi backup...${NC}"
        mkdir -p "$BACKUP_DIR"
        
        cat > "$BACKUP_CONFIG" << EOF
{
    "backup": {
        "enabled": false,
        "auto_backup": false,
        "backup_interval": "daily",
        "keep_local_backups": 7,
        "last_backup": null,
        "github_enabled": false
    },
    "telegram": {
        "enabled": false,
        "bot_token": "none",
        "chat_id": "",
        "notify_on_new_user": true,
        "notify_on_backup": true
    },
    "github": {
        "token": "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",
        "username": "rahmatstorevpn",
        "repo": "project",
        "backup_dir": "zivpn_backups"
    }
}
EOF
        echo -e "${GREEN}✓ Konfigurasi backup dibuat${NC}"
    fi
}

# Fungsi untuk membuat backup
create_backup() {
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="zivpn_backup_${timestamp}.tar.gz"
    local backup_path="$BACKUP_DIR/$backup_file"
    local github_url=""
    
    echo -e "${YELLOW}Membuat backup...${NC}"
    
    # Buat backup lokal
    tar -czf "$backup_path" \
        "$CONFIG_FILE" \
        "$USER_DB" \
        "$BACKUP_CONFIG" \
        "/etc/zivpn/zivpn.crt" \
        "/etc/zivpn/zivpn.key" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Backup lokal berhasil: $backup_file${NC}"
        
        # Upload ke GitHub jika diaktifkan
        if [ "$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null)" = "true" ]; then
            github_url=$(upload_to_github "$backup_path" "$backup_file")
        fi
        
        # Hapus backup lokal lama
        cleanup_old_backups
        
        # Update last backup time
        jq --arg time "$(date +"%Y-%m-%d %H:%M:%S")" '.backup.last_backup = $time' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG"
        
        # Kirim notifikasi ke Telegram
        send_backup_notification "$backup_file" "$github_url"
        
        return 0
    else
        echo -e "${RED}❌ Gagal membuat backup${NC}"
        return 1
    fi
}

# Fungsi untuk upload ke GitHub
upload_to_github() {
    local file_path=$1
    local filename=$2
    local github_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null)
    local github_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null)
    local github_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null)
    local backup_dir=$(jq -r '.github.backup_dir' "$BACKUP_CONFIG" 2>/dev/null)
    
    echo -e "${YELLOW}Mengupload ke GitHub...${NC}"
    
    # Cek apakah GitHub diaktifkan
    if [ "$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null)" != "true" ]; then
        echo -e "${YELLOW}GitHub backup tidak diaktifkan${NC}"
        return 1
    fi
    
    # Cek kredensial GitHub
    if [ -z "$github_token" ] || [ "$github_token" = "null" ] || \
       [ -z "$github_username" ] || [ "$github_username" = "null" ] || \
       [ -z "$github_repo" ] || [ "$github_repo" = "null" ]; then
        echo -e "${RED}❌ Kredensial GitHub belum lengkap${NC}"
        return 1
    fi
    
    # Encode file ke base64
    echo -e "${YELLOW}Encoding file...${NC}"
    local content_base64=$(base64 -w 0 "$file_path")
    
    if [ -z "$content_base64" ]; then
        echo -e "${RED}❌ Gagal encoding file${NC}"
        return 1
    fi
    
    # Buat payload JSON
    local payload=$(cat << EOF
{
    "message": "ZIVPN Backup $(date '+%Y-%m-%d %H:%M:%S')",
    "content": "$content_base64",
    "branch": "main"
}
EOF
    )
    
    # URL untuk upload file
    local upload_url="https://api.github.com/repos/$github_username/$github_repo/contents/$backup_dir/$filename"
    
    echo -e "${YELLOW}Mengupload ke $upload_url...${NC}"
    
    # Upload file menggunakan curl
    response=$(curl -s -X PUT "$upload_url" \
        -H "Authorization: token $github_token" \
        -H "Accept: application/vnd.github.v3+json" \
        -d "$payload")
    
    # Cek response
    if echo "$response" | grep -q '"content"'; then
        echo -e "${GREEN}✓ Upload ke GitHub berhasil${NC}"
        
        # Dapatkan download URL
        local download_url=$(echo "$response" | jq -r '.content.download_url' 2>/dev/null)
        if [ ! -z "$download_url" ] && [ "$download_url" != "null" ]; then
            echo -e "${CYAN}Download URL: ${GREEN}$download_url${NC}"
            
            # Simpan URL ke file untuk restore nanti
            local url_file="$BACKUP_DIR/${filename}.url"
            echo "$download_url" > "$url_file"
            
            # Kembalikan URL untuk digunakan di fungsi lain
            echo "$download_url"
            return 0
        fi
        return 0
    else
        echo -e "${RED}❌ Gagal upload ke GitHub${NC}"
        echo -e "${YELLOW}Response: $response${NC}"
        return 1
    fi
}

# Fungsi untuk download dari GitHub
download_from_github() {
    local backup_url=$1
    local filename=$(basename "$backup_url")
    local save_path="$BACKUP_DIR/$filename"
    
    echo -e "${YELLOW}Mendownload $filename...${NC}"
    
    # Download menggunakan curl
    if curl -s -L -o "$save_path" "$backup_url"; then
        echo -e "${GREEN}✓ Download berhasil: $filename${NC}"
        return 0
    else
        echo -e "${RED}❌ Gagal mendownload file${NC}"
        return 1
    fi
}

# Fungsi untuk hapus backup lama
cleanup_old_backups() {
    local keep_days=$(jq -r '.backup.keep_local_backups' "$BACKUP_CONFIG")
    
    if [ -z "$keep_days" ] || [ "$keep_days" = "null" ]; then
        keep_days=7
    fi
    
    echo -e "${YELLOW}Membersihkan backup lama (lebih dari $keep_days hari)...${NC}"
    
    # Hapus file backup yang lebih tua dari keep_days
    find "$BACKUP_DIR" -name "zivpn_backup_*.tar.gz" -mtime +$keep_days -delete 2>/dev/null
    find "$BACKUP_DIR" -name "zivpn_backup_*.tar.gz.url" -mtime +$keep_days -delete 2>/dev/null
    
    echo -e "${GREEN}✓ Backup lama telah dibersihkan${NC}"
}

# Fungsi untuk restore backup
restore_backup() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}🔄 RESTORE BACKUP${NC}\n"
        
        echo -e "${CYAN}Pilih sumber restore:${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}1. ${NC}Dari Backup Lokal"
        echo -e "${GREEN}2. ${NC}Dari GitHub URL"
        echo -e "${GREEN}3. ${NC}Kembali ke Menu Utama"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-3]: "${NC})" source_choice
        
        case $source_choice in
            1)
                restore_from_local
                ;;
            2)
                restore_from_github_url
                ;;
            3)
                return
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Fungsi untuk restore dari backup lokal
restore_from_local() {
    show_header
    echo -e "${CYAN}${BOLD}📂 RESTORE DARI BACKUP LOKAL${NC}\n"
    
    # Cek apakah ada backup lokal
    local backup_files=("$BACKUP_DIR"/zivpn_backup_*.tar.gz)
    
    if [ ${#backup_files[@]} -eq 0 ] || [ ! -f "${backup_files[0]}" ]; then
        echo -e "${YELLOW}Tidak ada backup lokal ditemukan${NC}"
        
        echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
        read
        return
    fi
    
    echo -e "${CYAN}Pilih backup untuk restore:${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    local i=1
    for file in "${backup_files[@]}"; do
        if [ -f "$file" ]; then
            local filename=$(basename "$file")
            local filedate=$(echo "$filename" | grep -o '[0-9]\{8\}_[0-9]\{6\}' || echo "")
            if [ ! -z "$filedate" ]; then
                local date_formatted=$(echo "$filedate" | sed 's/\(....\)\(..\)\(..\)_\(..\)\(..\)\(..\)/\1-\2-\3 \4:\5:\6/')
                echo -e "${GREEN}$i. ${NC}$filename (${date_formatted})"
            else
                echo -e "${GREEN}$i. ${NC}$filename"
            fi
            ((i++))
        fi
    done
    
    if [ $i -eq 1 ]; then
        echo -e "${YELLOW}Tidak ada backup yang valid${NC}"
        echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
        read
        return
    fi
    
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    read -p "$(echo -e ${YELLOW}"Pilih backup [1-$((i-1))]: "${NC})" choice
    
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le $((i-1)) ]; then
        local selected_file="${backup_files[$((choice-1))]}"
        perform_restore "$selected_file"
    else
        echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
        sleep 1
    fi
}

# Fungsi untuk restore dari GitHub URL
restore_from_github_url() {
    show_header
    echo -e "${CYAN}${BOLD}🌐 RESTORE DARI GITHUB URL${NC}\n"
    
    echo -e "${YELLOW}Masukkan URL backup dari GitHub:${NC}"
    echo -e "${CYAN}Contoh: https://raw.githubusercontent.com/rahmatstorevpn/project/main/zivpn_backups/zivpn_backup_20241215_120000.tar.gz${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    read -p "$(echo -e ${YELLOW}"URL: "${NC})" backup_url
    
    if [ -z "$backup_url" ]; then
        echo -e "${RED}❌ URL tidak boleh kosong${NC}"
        sleep 2
        return
    fi
    
    # Validasi URL
    if [[ ! "$backup_url" =~ ^https://.*\.tar\.gz$ ]]; then
        echo -e "${RED}❌ URL tidak valid. Harus berakhir dengan .tar.gz${NC}"
        sleep 2
        return
    fi
    
    # Download file dari URL
    local filename=$(basename "$backup_url")
    local temp_file="$BACKUP_DIR/temp_$filename"
    
    echo -e "${YELLOW}Mendownload backup dari:${NC}"
    echo -e "${CYAN}$backup_url${NC}"
    echo -e "${YELLOW}Mendownload...${NC}"
    
    if curl -s -L -o "$temp_file" "$backup_url"; then
        if [ -f "$temp_file" ] && [ -s "$temp_file" ]; then
            echo -e "${GREEN}✓ Download berhasil${NC}"
            echo -e "${CYAN}Size: $(du -h "$temp_file" | cut -f1)${NC}"
            
            # Simpan URL untuk referensi
            local url_file="$BACKUP_DIR/${filename}.source"
            echo "GitHub URL: $backup_url" > "$url_file"
            echo "Downloaded: $(date)" >> "$url_file"
            
            perform_restore "$temp_file"
        else
            echo -e "${RED}❌ File download kosong atau corrupt${NC}"
        fi
    else
        echo -e "${RED}❌ Gagal mendownload dari URL${NC}"
    fi
    
    # Hapus file temp jika masih ada
    [ -f "$temp_file" ] && rm -f "$temp_file"
}

# Fungsi untuk kirim notifikasi restore ke Telegram

# Fungsi untuk kirim notifikasi backup ke Telegram
send_backup_notification() {
    local backup_file=$1
    local github_url=$2
    
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        local backup_size=$(du -h "$BACKUP_DIR/$backup_file" 2>/dev/null | cut -f1 || echo "Unknown")
        local total_users=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        local backup_config=$(jq -r '.backup.keep_local_backups' "$BACKUP_CONFIG" 2>/dev/null || echo "7")
        
        local message="📦 BACKUP BERHASIL DIBUAT\n\n"
        message+="🖥️  Server: $server_ip\n"
        message+="📁 File: $backup_file\n"
        message+="📊 Size: $backup_size\n"
        message+="👥 Total User: $total_users\n"
        message+="🕐 Waktu: $(date)\n"
        message+="💾 Keep Local: $backup_config hari\n"
        
        # Tambahkan URL GitHub jika ada
        if [ ! -z "$github_url" ] && [ "$github_url" != "null" ]; then
            message+="\n🌐 GitHub URL:\n"
            message+="$github_url\n"
            message+="\n📥 Download via:\n"
            message+="curl -L \"$github_url\" -o backup.tar.gz\n"
        fi
        
        message+="\n✅ Backup selesai dan aman tersimpan"
        
        send_telegram_notification "$message"
    fi
}

# io
send_restore_notification() {
    local backup_file=$1
    local source=$2
    
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        
        local message="🔄 RESTORE BERHASIL\n\n"
        message+="🖥️  Server: $server_ip\n"
        message+="📁 File: $backup_file\n"
        message+="📂 Sumber: $source\n"
        message+="🕐 Waktu: $(date)\n"
        message+="👥 Total User: $(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")\n"
        
        message+="\n✅ Restore selesai, service telah direstart"
        
        send_telegram_notification "$message"
    fi
}

# Fungsi untuk melakukan restore
perform_restore() {
    local backup_file=$1
    local filename=$(basename "$backup_file")
    local source_type="Lokal"
    
    # Cek apakah dari GitHub URL
    if [[ "$backup_file" == *"temp_"* ]]; then
        source_type="GitHub URL"
    fi
    
    echo -e "\n${YELLOW}⚠️  Konfirmasi Restore${NC}"
    echo -e "${BOLD}────────────────────────────────────${NC}"
    echo -e "${RED}File yang akan di-restore:${NC}"
    echo -e "${RED}$filename${NC}"
    echo -e "${RED}Sumber: $source_type${NC}"
    echo -e "${BOLD}────────────────────────────────────${NC}"
    echo -e "${YELLOW}PERINGATAN: Restore akan mengganti semua konfigurasi saat ini!${NC}"
    
    read -p "$(echo -e ${YELLOW}"Lanjutkan? (y/n): "${NC})" confirm
    
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Restore dibatalkan${NC}"
        sleep 1
        return
    fi
    
    # Backup konfigurasi saat ini dulu
    local current_backup="$BACKUP_DIR/current_before_restore_$(date +"%Y%m%d_%H%M%S").tar.gz"
    echo -e "${YELLOW}Membuat backup konfigurasi saat ini...${NC}"
    tar -czf "$current_backup" \
        "$CONFIG_FILE" \
        "$USER_DB" \
        "$BACKUP_CONFIG" \
        "/etc/zivpn/zivpn.crt" \
        "/etc/zivpn/zivpn.key" 2>/dev/null
    
    # Ekstrak backup yang dipilih
    echo -e "${YELLOW}Melakukan restore...${NC}"
    tar -xzf "$backup_file" -C /
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Restore berhasil${NC}"
        
        # Restart service
        restart_service
        
        # Kirim notifikasi
        send_restore_notification "$filename" "$source_type"
        
        echo -e "\n${GREEN}Service telah direstart dengan konfigurasi baru${NC}"
    else
        echo -e "${RED}❌ Gagal melakukan restore${NC}"
        
        # Rollback jika gagal
        echo -e "${YELLOW}Melakukan rollback...${NC}"
        tar -xzf "$current_backup" -C /
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ Rollback berhasil${NC}"
        else
            echo -e "${RED}❌ Gagal rollback${NC}"
        fi
    fi
    
    echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
    read
}

# Fungsi untuk mengatur konfigurasi backup
configure_backup() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}⚙️  KONFIGURASI BACKUP${NC}\n"
        
        local backup_enabled=$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local auto_backup=$(jq -r '.backup.auto_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local github_enabled=$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local backup_interval=$(jq -r '.backup.backup_interval' "$BACKUP_CONFIG" 2>/dev/null || echo "daily")
        local keep_backups=$(jq -r '.backup.keep_local_backups' "$BACKUP_CONFIG" 2>/dev/null || echo "7")
        local telegram_enabled=$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local github_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null || echo "")
        local github_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null || echo "")
        local github_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null || echo "")
        
        echo -e "${BG_PURPLE}${BOLD}   SETTING BACKUP   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}1. Backup System      : ${GREEN}$backup_enabled${NC}"
        echo -e "${CYAN}2. Auto Backup        : ${GREEN}$auto_backup${NC}"
        echo -e "${CYAN}3. GitHub Backup      : ${GREEN}$github_enabled${NC}"
        echo -e "${CYAN}4. Interval Backup    : ${GREEN}$backup_interval${NC}"
        echo -e "${CYAN}5. Keep Local Backups : ${GREEN}$keep_backups hari${NC}"
        echo -e "${CYAN}6. Telegram Notify    : ${GREEN}$telegram_enabled${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}7. Konfigurasi GitHub${NC}"
        echo -e "${CYAN}8. Konfigurasi Telegram${NC}"
        echo -e "${CYAN}9. Test Backup${NC}"
        echo -e "${CYAN}10. Test Telegram${NC}"
        echo -e "${CYAN}11. Kembali ke Menu Utama${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-11]: "${NC})" choice
        
        case $choice in
            1)
                toggle_setting "backup.enabled"
                ;;
            2)
                toggle_setting "backup.auto_backup"
                ;;
            3)
                toggle_setting "backup.github_enabled"
                ;;
            4)
                set_backup_interval
                ;;
            5)
                set_keep_backups
                ;;
            6)
                toggle_setting "telegram.enabled"
                ;;
            7)
                configure_github
                ;;
            8)
                configure_telegram
                ;;
            9)
                create_backup
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            10)
                test_telegram
                ;;
            11)
                break
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Fungsi untuk toggle setting
toggle_setting() {
    local setting=$1
    local current_value=$(jq -r ".$setting" "$BACKUP_CONFIG" 2>/dev/null)
    
    if [ "$current_value" = "true" ]; then
        jq ".$setting = false" "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
        echo -e "${YELLOW}✓ Setting dinonaktifkan${NC}"
    else
        jq ".$setting = true" "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
        echo -e "${GREEN}✓ Setting diaktifkan${NC}"
    fi
    
    sleep 1
}

# Fungsi untuk set backup interval
set_backup_interval() {
    echo -e "\n${CYAN}Pilih interval backup:${NC}"
    echo -e "${GREEN}1. ${NC}Daily"
    echo -e "${GREEN}2. ${NC}Weekly"
    echo -e "${GREEN}3. ${NC}Monthly"
    
    read -p "$(echo -e ${YELLOW}"Pilih [1-3]: "${NC})" interval_choice
    
    case $interval_choice in
        1) interval="daily" ;;
        2) interval="weekly" ;;
        3) interval="monthly" ;;
        *) 
            echo -e "${RED}❌ Pilihan tidak valid!${NC}"
            sleep 1
            return
            ;;
    esac
    
    jq --arg int "$interval" '.backup.backup_interval = $int' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    echo -e "${GREEN}✓ Interval backup diatur ke $interval${NC}"
    sleep 1
}

# Fungsi untuk set keep backups
set_keep_backups() {
    read -p "$(echo -e ${YELLOW}"Masukkan jumlah hari menyimpan backup lokal [7-30]: "${NC})" days
    
    if [[ "$days" =~ ^[0-9]+$ ]] && [ "$days" -ge 7 ] && [ "$days" -le 30 ]; then
        jq --argjson days "$days" '.backup.keep_local_backups = $days' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
        echo -e "${GREEN}✓ Backup lokal akan disimpan selama $days hari${NC}"
    else
        echo -e "${RED}❌ Masukkan angka antara 7-30${NC}"
    fi
    
    sleep 1
}

# Fungsi untuk konfigurasi GitHub
configure_github() {
    echo -e "\n${CYAN}Konfigurasi GitHub:${NC}"
    
    local current_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null)
    local current_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null)
    local current_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null)
    local current_dir=$(jq -r '.github.backup_dir' "$BACKUP_CONFIG" 2>/dev/null)
    
    echo -e "${YELLOW}Token saat ini: ${GREEN}$current_token${NC}"
    read -p "$(echo -e ${YELLOW}"GitHub Token (tekan Enter untuk tidak mengubah): "${NC})" new_token
    
    echo -e "${YELLOW}Username saat ini: ${GREEN}$current_username${NC}"
    read -p "$(echo -e ${YELLOW}"GitHub Username (tekan Enter untuk tidak mengubah): "${NC})" new_username
    
    echo -e "${YELLOW}Repository saat ini: ${GREEN}$current_repo${NC}"
    read -p "$(echo -e ${YELLOW}"Repository Name (tekan Enter untuk tidak mengubah): "${NC})" new_repo
    
    echo -e "${YELLOW}Backup directory saat ini: ${GREEN}$current_dir${NC}"
    read -p "$(echo -e ${YELLOW}"Backup Directory (tekan Enter untuk tidak mengubah): "${NC})" new_dir
    
    # Update konfigurasi
    if [ ! -z "$new_token" ]; then
        jq --arg token "$new_token" '.github.token = $token' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_username" ]; then
        jq --arg username "$new_username" '.github.username = $username' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_repo" ]; then
        jq --arg repo "$new_repo" '.github.repo = $repo' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_dir" ]; then
        jq --arg dir "$new_dir" '.github.backup_dir = $dir' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    echo -e "${GREEN}✓ Konfigurasi GitHub diperbarui${NC}"
    
    # Test koneksi GitHub
    echo -e "${YELLOW}Menguji koneksi GitHub...${NC}"
    if test_github_connection; then
        echo -e "${GREEN}✓ Koneksi GitHub berhasil${NC}"
    else
        echo -e "${RED}❌ Gagal terhubung ke GitHub${NC}"
    fi
    
    sleep 2
}

# Fungsi untuk test koneksi GitHub
test_github_connection() {
    local github_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null)
    local github_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null)
    local github_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null)
    
    if [ -z "$github_token" ] || [ "$github_token" = "null" ] || \
       [ -z "$github_username" ] || [ "$github_username" = "null" ] || \
       [ -z "$github_repo" ] || [ "$github_repo" = "null" ]; then
        return 1
    fi
    
    # Test API GitHub
    response=$(curl -s -H "Authorization: token $github_token" \
        "https://api.github.com/repos/$github_username/$github_repo" 2>/dev/null)
    
    if echo "$response" | grep -q '"full_name"'; then
        return 0
    else
        return 1
    fi
}

# Fungsi untuk konfigurasi Telegram
configure_telegram() {
    echo -e "\n${CYAN}Konfigurasi Telegram:${NC}"
    
    local current_token=$(jq -r '.telegram.bot_token' "$BACKUP_CONFIG" 2>/dev/null)
    local current_chat_id=$(jq -r '.telegram.chat_id' "$BACKUP_CONFIG" 2>/dev/null)
    
    echo -e "${YELLOW}Bot Token saat ini: ${GREEN}$current_token${NC}"
    read -p "$(echo -e ${YELLOW}"Bot Token (tekan Enter untuk tidak mengubah): "${NC})" new_token
    
    echo -e "${YELLOW}Chat ID saat ini: ${GREEN}$current_chat_id${NC}"
    read -p "$(echo -e ${YELLOW}"Chat ID (tekan Enter untuk tidak mengubah): "${NC})" new_chat_id
    
    # Update konfigurasi
    if [ ! -z "$new_token" ]; then
        jq --arg token "$new_token" '.telegram.bot_token = $token' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_chat_id" ]; then
        jq --arg chat "$new_chat_id" '.telegram.chat_id = $chat' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    echo -e "${GREEN}✓ Konfigurasi Telegram diperbarui${NC}"
    
    # Test koneksi Telegram
    echo -e "${YELLOW}Menguji koneksi Telegram...${NC}"
    if send_telegram_notification "✅ Bot Telegram berhasil dikonfigurasi!\n\nWaktu: $(date)\nServer: $(hostname)"; then
        echo -e "${GREEN}✓ Test notifikasi berhasil dikirim${NC}"
    else
        echo -e "${RED}❌ Gagal mengirim notifikasi${NC}"
    fi
    
    sleep 2
}

# Fungsi untuk test Telegram
test_telegram() {
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        echo -e "${YELLOW}Mengirim test notifikasi...${NC}"
        
        if send_telegram_notification "🔔 Test Notifikasi dari ZIVPN Manager\n\nWaktu: $(date)\nServer: $(hostname)\nIP: $(get_server_ip)\n\n✅ Bot Telegram berfungsi dengan baik!"; then
            echo -e "${GREEN}✓ Test notifikasi berhasil dikirim${NC}"
        else
            echo -e "${RED}❌ Gagal mengirim notifikasi${NC}"
        fi
    else
        echo -e "${YELLOW}Telegram belum dikonfigurasi${NC}"
    fi
    
    sleep 2
}

# Fungsi untuk mengirim notifikasi ke Telegram
send_telegram_notification() {
    local message="$1"
    local bot_token=$(jq -r '.telegram.bot_token' "$BACKUP_CONFIG" 2>/dev/null)
    local chat_id=$(jq -r '.telegram.chat_id' "$BACKUP_CONFIG" 2>/dev/null)
    
    if [ "$bot_token" != "null" ] && [ "$chat_id" != "null" ] && \
       [ ! -z "$bot_token" ] && [ ! -z "$chat_id" ] && \
       [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        # Encode message untuk URL
        local encoded_message=$(echo -e "$message" | sed 's/ /%20/g; s/\n/%0A/g')
        
        # Kirim via curl
        curl -s -X POST "https://api.telegram.org/bot${bot_token}/sendMessage" \
            -d "chat_id=${chat_id}" \
            -d "text=${encoded_message}" \
            -d "parse_mode=HTML" > /dev/null 2>&1
            
        if [ $? -eq 0 ]; then
            return 0
        else
            return 1
        fi
    fi
    
    return 1
}

# Fungsi untuk auto backup
auto_backup() {
    local last_backup=$(jq -r '.backup.last_backup' "$BACKUP_CONFIG" 2>/dev/null)
    local interval=$(jq -r '.backup.backup_interval' "$BACKUP_CONFIG" 2>/dev/null || echo "daily")
    
    if [ "$last_backup" = "null" ] || [ -z "$last_backup" ]; then
        # Belum pernah backup, buat backup sekarang
        create_backup
        return
    fi
    
    # Konversi last_backup ke timestamp
    local last_timestamp=$(date -d "$last_backup" +%s 2>/dev/null)
    if [ $? -ne 0 ]; then
        # Format tanggal tidak valid, buat backup baru
        create_backup
        return
    fi
    
    local current_timestamp=$(date +%s)
    local diff_seconds=$((current_timestamp - last_timestamp))
    
    # Tentukan interval dalam detik
    case $interval in
        "daily")
            local interval_seconds=86400  # 1 hari
            ;;
        "weekly")
            local interval_seconds=604800  # 7 hari
            ;;
        "monthly")
            local interval_seconds=2592000  # 30 hari
            ;;
        *)
            local interval_seconds=86400
            ;;
    esac
    
    # Cek apakah sudah waktunya backup
    if [ $diff_seconds -ge $interval_seconds ]; then
        echo -e "${YELLOW}🔄 Menjalankan auto backup...${NC}"
        create_backup
    fi
}

# Fungsi untuk kirim notifikasi ketika user baru dibuat
send_new_user_notification() {
    local username=$1
    local password=$2
    local expiry=$3
    local period=$4
    
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_new_user' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        local message="👤 USER BARU DITAMBAHKAN\n\n"
        message+="📱 Username: $username\n"
        message+="🔑 Password: $password\n"
        message+="📅 Masa Aktif: $period\n"
        
        if [ "$expiry" != "unlimited" ]; then
            message+="⏰ Expired: $expiry\n"
        fi
        
        message+="\n🌐 Server: $server_ip\n"
        message+="🔌 Port: 5667\n"
        message+="🕐 Waktu: $(date)\n\n"
        message+="✅ User berhasil ditambahkan ke sistem"
        
        send_telegram_notification "$message"
    fi
}

# ==============================
# FUNGSI UTAMA YANG DIUBAH
# ==============================

# Tambah user baru dengan masa aktif
add_user() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}➕ TAMBAH USER BARU${NC}\n"
        
        read -p "$(echo -e ${YELLOW}"Masukkan Username: "${NC})" username
        
        if [ -z "$username" ]; then
            echo -e "\n${RED}❌ Username tidak boleh kosong!${NC}"
            sleep 2
            continue
        fi
        
        # Cek apakah username sudah ada
        if jq -e ".users.\"$username\"" "$USER_DB" >/dev/null 2>&1; then
            echo -e "\n${RED}❌ Username '$username' sudah ada!${NC}"
            sleep 2
            continue
        fi
        
        read -p "$(echo -e ${YELLOW}"Masukkan Password: "${NC})" password
        
        if [ -z "$password" ]; then
            echo -e "\n${RED}❌ Password tidak boleh kosong!${NC}"
            sleep 2
            continue
        fi
        
        echo -e "\n${CYAN}Pilih Masa Aktif:${NC}"
        echo -e "${GREEN}1. ${NC}7 Hari"
        echo -e "${GREEN}2. ${NC}30 Hari"
        echo -e "${GREEN}3. ${NC}90 Hari"
        echo -e "${GREEN}4. ${NC}1 Tahun"
        echo -e "${GREEN}5. ${NC}Unlimited"
        echo -e "${GREEN}6. ${NC}Custom"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-6]: "${NC})" period_choice
        
        case $period_choice in
            1)
                expiry_date=$(date -d "+7 days" "+%Y-%m-%d")
                period="7 Hari"
                ;;
            2)
                expiry_date=$(date -d "+30 days" "+%Y-%m-%d")
                period="30 Hari"
                ;;
            3)
                expiry_date=$(date -d "+90 days" "+%Y-%m-%d")
                period="90 Hari"
                ;;
            4)
                expiry_date=$(date -d "+1 year" "+%Y-%m-%d")
                period="1 Tahun"
                ;;
            5)
                expiry_date="unlimited"
                period="Unlimited"
                ;;
            6)
                read -p "$(echo -e ${YELLOW}"Masukkan jumlah hari: "${NC})" custom_days
                if [[ "$custom_days" =~ ^[0-9]+$ ]] && [ "$custom_days" -gt 0 ]; then
                    expiry_date=$(date -d "+$custom_days days" "+%Y-%m-%d")
                    period="$custom_days Hari"
                else
                    echo -e "\n${RED}❌ Jumlah hari tidak valid!${NC}"
                    sleep 2
                    continue
                fi
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 2
                continue
                ;;
        esac
        
        # Backup sebelum modifikasi
        backup_config
        
        # Tambah password ke config
        if jq --arg p "$password" '.auth.config += [$p]' "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"; then
            # Tambah ke database user
            current_date=$(date "+%Y-%m-%d %H:%M:%S")
            jq --arg user "$username" \
               --arg pass "$password" \
               --arg expiry "$expiry_date" \
               --arg created "$current_date" \
               '.users[$user] = {
                   password: $pass,
                   created_date: $created,
                   expiry_date: $expiry,
                   last_login: null,
                   device_count: 0,
                   is_active: true
               }' "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
            
            echo -e "\n${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
            echo -e "${GREEN}${BOLD}                    USER BERHASIL DITAMBAHKAN!                ${NC}"
            echo -e "${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
            
            # Ambil IP server
            SERVER_IP=$(get_server_ip)
            
            # Tampilkan informasi
            echo -e "\n${BG_GREEN}${BOLD}   INFORMASI USER   ${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            echo -e "${CYAN}Username      : ${GREEN}${BOLD}$username${NC}"
            echo -e "${CYAN}Password      : ${GREEN}${BOLD}$password${NC}"
            echo -e "${CYAN}Masa Aktif    : ${GREEN}${BOLD}$period${NC}"
            
            if [ "$expiry_date" != "unlimited" ]; then
                echo -e "${CYAN}Expired Date  : ${GREEN}${BOLD}$expiry_date${NC}"
            fi
            
            echo -e "${CYAN}Tanggal Buat  : ${GREEN}${BOLD}$current_date${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            
            echo -e "\n${BG_BLUE}${BOLD}   INFORMASI KONEKSI   ${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            echo -e "${CYAN}IP Server     : ${GREEN}${BOLD}$SERVER_IP${NC}"
            echo -e "${CYAN}Port          : ${GREEN}${BOLD}5667${NC}"
            echo -e "${CYAN}Protocol      : ${GREEN}${BOLD}UDP${NC}"
            echo -e "${CYAN}OBFS          : ${GREEN}${BOLD}zivpn${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            
            echo -e "\n${YELLOW}💡 Catatan untuk customer:${NC}"
            echo -e "${PURPLE}• Username: ${BOLD}kosongkan${NC}"
            echo -e "${PURPLE}• Password: ${BOLD}$password${NC}"
            echo -e "${PURPLE}• Max perangkat: ${BOLD}$(jq -r '.settings.max_devices_per_user' "$USER_DB" 2>/dev/null || echo "3")${NC}"
            
            # Restart service
            restart_service
            
            echo -e "\n${YELLOW}📋 Total user sekarang: ${GREEN}$(jq '.users | length' "$USER_DB")${NC}"
            
            # Auto backup jika diaktifkan
            if [ "$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
               [ "$(jq -r '.backup.auto_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
                echo -e "\n${YELLOW}🔄 Menjalankan auto backup...${NC}"
                create_backup
            fi
            
            # Kirim notifikasi ke Telegram
            send_new_user_notification "$username" "$password" "$expiry_date" "$period"
            
            read -p "$(echo -e ${YELLOW}"Tambahkan user lagi? (y/n): "${NC})" add_more
            if [[ ! "$add_more" =~ ^[Yy]$ ]]; then
                break
            fi
        else
            echo -e "\n${RED}❌ Gagal menambahkan user!${NC}"
            sleep 2
        fi
    done
}

# Lihat semua user
list_users() {
    while true; do
        show_header
        echo -e "${BLUE}${BOLD}📋 DAFTAR SEMUA USER${NC}\n"
        
        # Cek apakah ada user
        user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "${YELLOW}Belum ada user terdaftar${NC}"
        else
            # Ambil IP server
            SERVER_IP=$(get_server_ip)
            
            echo -e "${BG_PURPLE}${BOLD}   INFORMASI SERVER   ${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            echo -e "${CYAN}IP Server     : ${GREEN}${BOLD}$SERVER_IP${NC}"
            echo -e "${CYAN}Port          : ${GREEN}${BOLD}5667${NC}"
            echo -e "${CYAN}Total User    : ${GREEN}${BOLD}$user_count${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}\n"
            
            echo -e "${CYAN}${BOLD}Daftar User:${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            
            printf "%-20s %-25s %-15s %-12s\n" "Username" "Created" "Expiry" "Status"
            echo -e "${BOLD}────────────────────────────────────────────────────────${NC}"
            
            jq -r '.users | to_entries[] | "\(.key)|\(.value.created_date)|\(.value.expiry_date)"' "$USER_DB" 2>/dev/null | while IFS='|' read username created expiry; do
                status=$(check_expiry "$username")
                
                if [ "$status" = "expired" ]; then
                    status_text="${RED}EXPIRED${NC}"
                    expiry_text="${RED}$expiry${NC}"
                elif [ "$status" = "no_expiry" ]; then
                    status_text="${GREEN}ACTIVE${NC}"
                    expiry_text="${GREEN}Unlimited${NC}"
                elif [[ "$status" =~ ^[0-9]+$ ]]; then
                    status_text="${GREEN}ACTIVE${NC}"
                    expiry_text="${GREEN}$status days${NC}"
                else
                    status_text="${YELLOW}$status${NC}"
                    expiry_text="${YELLOW}$expiry${NC}"
                fi
                
                printf "%-20s %-25s %-15s %-30s\n" "$username" "$created" "$(echo -e "$expiry_text")" "$(echo -e "$status_text")"
            done
            
            echo -e "\n${YELLOW}📊 Statistik Masa Aktif:${NC}"
            echo -e "${BOLD}────────────────────────────────────${NC}"
            
            # Hitung user aktif vs expired
            active_count=0
            expired_count=0
            
            jq -r '.users | keys[]' "$USER_DB" 2>/dev/null | while read username; do
                status=$(check_expiry "$username")
                if [ "$status" = "expired" ]; then
                    ((expired_count++))
                else
                    ((active_count++))
                fi
            done
            
            echo -e "${CYAN}User Aktif     : ${GREEN}$active_count${NC}"
            echo -e "${CYAN}User Expired   : ${RED}$expired_count${NC}"
            echo -e "${CYAN}Total User     : ${YELLOW}$user_count${NC}"
            echo -e "${BOLD}────────────────────────────────────${NC}"
        fi
        
        echo -e "\n${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${YELLOW}1. ${NC}Tambah User Baru"
        echo -e "${YELLOW}2. ${NC}Hapus User"
        echo -e "${YELLOW}3. ${NC}Cek User Login"
        echo -e "${YELLOW}4. ${NC}Auto Cleanup Expired"
        echo -e "${YELLOW}5. ${NC}Kembali ke Menu Utama"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${PURPLE}"Pilih [1-5]: "${NC})" choice
        
        case $choice in
            1) add_user ;;
            2) delete_user ;;
            3) check_user_login ;;
            4) 
                auto_cleanup_expired
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            5) break ;;
            *) 
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# ==============================
# UPDATE MAIN MENU
# ==============================

# Fungsi untuk menu backup & restore
backup_restore_menu() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}💾 BACKUP & RESTORE${NC}\n"
        
        local last_backup=$(jq -r '.backup.last_backup' "$BACKUP_CONFIG" 2>/dev/null)
        if [ "$last_backup" = "null" ] || [ -z "$last_backup" ]; then
            last_backup="Belum pernah"
        fi
        
        local backup_enabled=$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local github_enabled=$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        
        echo -e "${BG_PURPLE}${BOLD}   INFORMASI BACKUP   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}Last Backup     : ${GREEN}$last_backup${NC}"
        echo -e "${CYAN}Backup Enabled  : ${GREEN}$backup_enabled${NC}"
        echo -e "${CYAN}GitHub Backup   : ${GREEN}$github_enabled${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}1. ${NC}Buat Backup Sekarang"
        echo -e "${BLUE}2. ${NC}Restore dari Backup"
        echo -e "${YELLOW}3. ${NC}Lihat Backup Lokal"
        echo -e "${PURPLE}4. ${NC}Kembali ke Menu Utama"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-4]: "${NC})" choice
        
        case $choice in
            1)
                create_backup
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            2)
                restore_backup
                ;;
            3)
                list_local_backups
                ;;
            4)
                break
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Fungsi untuk list backup lokal
list_local_backups() {
    show_header
    echo -e "${CYAN}${BOLD}📂 BACKUP LOKAL${NC}\n"
    
    # Buat array backup files
    local backup_files=()
    while IFS= read -r -d $'\0' file; do
        backup_files+=("$file")
    done < <(find "$BACKUP_DIR" -name "zivpn_backup_*.tar.gz" -print0 2>/dev/null)
    
    if [ ${#backup_files[@]} -eq 0 ]; then
        echo -e "${YELLOW}Tidak ada backup lokal${NC}"
    else
        echo -e "${BG_PURPLE}${BOLD}   DAFTAR BACKUP   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        local total_size=0
        for file in "${backup_files[@]}"; do
            if [ -f "$file" ]; then
                local filename=$(basename "$file")
                local size=$(du -h "$file" 2>/dev/null | cut -f1 || echo "0B")
                local filedate=$(echo "$filename" | grep -o '[0-9]\{8\}_[0-9]\{6\}' || echo "")
                local date_formatted=""
                if [ ! -z "$filedate" ]; then
                    date_formatted=$(echo "$filedate" | sed 's/\(....\)\(..\)\(..\)_\(..\)\(..\)\(..\)/\1-\2-\3 \4:\5:\6/')
                fi
                
                echo -e "${GREEN}📁 ${NC}$filename"
                echo -e "   📅 $date_formatted | 📊 $size"
                echo -e "${BOLD}────────────────────────────────────────────────────────${NC}"
                
                # Hitung total size
                local size_bytes=$(stat -c%s "$file" 2>/dev/null || echo "0")
                total_size=$((total_size + size_bytes))
            fi
        done
        
        echo -e "${CYAN}Total Backup : ${GREEN}${#backup_files[@]} files${NC}"
        if [ $total_size -gt 0 ]; then
            echo -e "${CYAN}Total Size   : ${GREEN}$(echo "scale=2; $total_size/1024/1024" | bc) MB${NC}"
        else
            echo -e "${CYAN}Total Size   : ${GREEN}0 MB${NC}"
        fi
    fi
    
    echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
    read
}

# Update main_menu() untuk tambah menu backup
main_menu() {
    # Install dependencies
    install_dependencies
    
    # Inisialisasi database
    init_user_db
    ensure_config_structure
    
    # Inisialisasi konfigurasi backup
    init_backup_config
    
    # Jalankan auto cleanup saat start
    auto_cleanup_expired
    
    # Jalankan auto backup jika waktunya
    if [ "$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.backup.auto_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        auto_backup
    fi
    
    while true; do
        show_header
        
        # Cek status service
        if systemctl is-active --quiet $SERVICE 2>/dev/null; then
            status="${GREEN}● RUNNING${NC}"
        else
            status="${RED}● STOPPED${NC}"
        fi
        
        # Hitung jumlah user
        user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        
        # Ambil IP server
        SERVER_IP=$(get_server_ip)
        
        # Hitung user aktif vs expired
        active_count=0
        expired_count=0
        
        jq -r '.users | keys[]' "$USER_DB" 2>/dev/null | while read username; do
            status_check=$(check_expiry "$username")
            if [ "$status_check" = "expired" ]; then
                ((expired_count++))
            else
                ((active_count++))
            fi
        done
        
        # Cek status backup
        if [ "$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
            backup_status="${GREEN}● AKTIF${NC}"
        else
            backup_status="${RED}● NONAKTIF${NC}"
        fi
        
        echo -e "${CYAN}${BOLD}📱 MENU UTAMA ZIVPN BISNIS${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}Status Service  :${NC} $status"
        echo -e "${CYAN}Status Backup   :${NC} $backup_status"
        echo -e "${CYAN}IP Server       :${NC} ${GREEN}${BOLD}$SERVER_IP${NC}"
        echo -e "${CYAN}Port            :${NC} ${GREEN}${BOLD}5667${NC}"
        echo -e "${CYAN}Total User      :${NC} ${YELLOW}${BOLD}$user_count${NC}"
        echo -e "${CYAN}User Aktif      :${NC} ${GREEN}${BOLD}$active_count${NC}"
        echo -e "${CYAN}User Expired    :${NC} ${RED}${BOLD}$expired_count${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}${BOLD}1. ${NC}${BOLD}➕ Tambah User Baru${NC}"
        echo -e "${RED}${BOLD}2. ${NC}${BOLD}🗑️  Hapus User${NC}"
        echo -e "${BLUE}${BOLD}3. ${NC}${BOLD}📋 Lihat Semua User${NC}"
        echo -e "${CYAN}${BOLD}4. ${NC}${BOLD}👥 Cek User Login${NC}"
        echo -e "${YELLOW}${BOLD}5. ${NC}${BOLD}🔄 Restart Service${NC}"
        echo -e "${PURPLE}${BOLD}6. ${NC}${BOLD}🧹 Auto Cleanup Expired${NC}"
        echo -e "${GREEN}${BOLD}7. ${NC}${BOLD}💾 Backup & Restore${NC}"
        echo -e "${CYAN}${BOLD}8. ${NC}${BOLD}⚙️  Konfigurasi Backup${NC}"
        echo -e "${YELLOW}${BOLD}9. ${NC}${BOLD}🚪 Keluar${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${PURPLE}"Pilih menu [1-9]: "${NC})" choice

        case $choice in
            1) add_user ;;
            2) delete_user ;;
            3) list_users ;;
            4) check_user_login ;;
            5) 
                show_header
                echo -e "${CYAN}${BOLD}🔄 RESTART SERVICE ZIVPN${NC}\n"
                restart_service
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            6)
                auto_cleanup_expired
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            7) 
                backup_restore_menu
                ;;
            8)
                configure_backup
                ;;
            9) 
                show_header
                echo -e "\n${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
                echo -e "${GREEN}${BOLD}                    TERIMA KASIH!                            ${NC}"
                echo -e "${GREEN}${BOLD}            Semoga bisnis lancar! 💰                         ${NC}"
                echo -e "${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}\n"
                exit 0 
                ;;
            *) 
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Trap untuk exit bersih
trap 'echo -e "\n${YELLOW}Script dihentikan${NC}"; exit 1' INT TERM

# Jalankan main menu
main_menu