#!/bin/bash

CONFIG_FILE="/etc/zivpn/config.json"
USER_DB="/etc/zivpn/users.json"
LOG_FILE="/var/log/zivpn.log"
BACKUP_DIR="/etc/zivpn/backups"
SERVICE="zivpn"

# Konfigurasi Backup
BACKUP_CONFIG="/etc/zivpn/backup_config.json"

# Konfigurasi Domain
DOMAIN_FILE="/etc/zivpn/domain.json"

# Konfigurasi GitHub
GITHUB_TOKEN="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"
GITHUB_USERNAME="rahmatstorevpn"
GITHUB_REPO="project"
GITHUB_BACKUP_DIR="zivpn_backups"

# Warna untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'
BG_BLUE='\033[44m'
BG_GREEN='\033[42m'
BG_YELLOW='\033[43m'
BG_RED='\033[41m'
BG_PURPLE='\033[45m'
BG_CYAN='\033[46m'

# ==============================
# FUNGSI INISIALISASI
# ==============================

# Fungsi untuk mendapatkan IP server
get_server_ip() {
    if command -v curl &>/dev/null; then
        ip=$(curl -s https://api.ipify.org)
    elif command -v wget &>/dev/null; then
        ip=$(wget -qO- https://api.ipify.org)
    else
        ip=$(hostname -I | awk '{print $1}')
    fi
    echo "$ip"
}

# Fungsi untuk tampilan header
show_header() {
    clear
    echo -e "${BG_BLUE}${BOLD}════════════════════════════════════════════════════════════${NC}"
    echo -e "${BG_BLUE}${BOLD}             ZIVPN MANAGER - BISNIS VPN                    ${NC}"
    echo -e "${BG_BLUE}${BOLD}════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# Fungsi untuk inisialisasi domain
init_domain() {
    if [ ! -f "$DOMAIN_FILE" ]; then
        echo -e "${YELLOW}Membuat konfigurasi domain...${NC}"
        cat > "$DOMAIN_FILE" << EOF
{
    "domain": "",
    "subdomain": "",
    "auto_display": true,
    "last_update": null
}
EOF
        echo -e "${GREEN}✓ Konfigurasi domain dibuat${NC}"
    fi
}

# Fungsi untuk mendapatkan domain
get_domain() {
    if [ -f "$DOMAIN_FILE" ]; then
        domain=$(jq -r '.domain' "$DOMAIN_FILE" 2>/dev/null)
        subdomain=$(jq -r '.subdomain' "$DOMAIN_FILE" 2>/dev/null)
        
        if [ "$domain" != "null" ] && [ ! -z "$domain" ]; then
            if [ "$subdomain" != "null" ] && [ ! -z "$subdomain" ]; then
                echo "$subdomain.$domain"
            else
                echo "$domain"
            fi
        else
            echo ""
        fi
    else
        echo ""
    fi
}

# Fungsi untuk mengatur domain
configure_domain() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}🌐 KONFIGURASI DOMAIN${NC}\n"
        
        current_domain=$(jq -r '.domain' "$DOMAIN_FILE" 2>/dev/null)
        current_subdomain=$(jq -r '.subdomain' "$DOMAIN_FILE" 2>/dev/null)
        auto_display=$(jq -r '.auto_display' "$DOMAIN_FILE" 2>/dev/null)
        
        echo -e "${BG_CYAN}${BOLD}   SETTING DOMAIN   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}Domain saat ini      : ${GREEN}$current_domain${NC}"
        echo -e "${CYAN}Subdomain saat ini   : ${GREEN}$current_subdomain${NC}"
        echo -e "${CYAN}Tampilkan otomatis   : ${GREEN}$auto_display${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}1. ${NC}Set Domain Utama"
        echo -e "${GREEN}2. ${NC}Set Subdomain"
        echo -e "${GREEN}3. ${NC}Toggle Tampilan Otomatis"
        echo -e "${GREEN}4. ${NC}Test Domain"
        echo -e "${GREEN}5. ${NC}Kembali ke Menu Utama"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-5]: "${NC})" choice
        
        case $choice in
            1)
                echo -e "\n${YELLOW}Masukkan domain utama (contoh: example.com):${NC}"
                read -p "Domain: " new_domain
                if [ ! -z "$new_domain" ]; then
                    jq --arg domain "$new_domain" '.domain = $domain' "$DOMAIN_FILE" > tmp.json && mv tmp.json "$DOMAIN_FILE"
                    jq --arg time "$(date +"%Y-%m-%d %H:%M:%S")" '.last_update = $time' "$DOMAIN_FILE" > tmp.json && mv tmp.json "$DOMAIN_FILE"
                    echo -e "${GREEN}✓ Domain utama disimpan: $new_domain${NC}"
                else
                    echo -e "${RED}❌ Domain tidak boleh kosong${NC}"
                fi
                sleep 2
                ;;
            2)
                echo -e "\n${YELLOW}Masukkan subdomain (contoh: vpn atau kosongkan jika tidak ada):${NC}"
                read -p "Subdomain: " new_subdomain
                jq --arg subdomain "$new_subdomain" '.subdomain = $subdomain' "$DOMAIN_FILE" > tmp.json && mv tmp.json "$DOMAIN_FILE"
                jq --arg time "$(date +"%Y-%m-%d %H:%M:%S")" '.last_update = $time' "$DOMAIN_FILE" > tmp.json && mv tmp.json "$DOMAIN_FILE"
                echo -e "${GREEN}✓ Subdomain disimpan: $new_subdomain${NC}"
                sleep 2
                ;;
            3)
                current=$(jq -r '.auto_display' "$DOMAIN_FILE")
                if [ "$current" = "true" ]; then
                    jq '.auto_display = false' "$DOMAIN_FILE" > tmp.json && mv tmp.json "$DOMAIN_FILE"
                    echo -e "${YELLOW}✓ Tampilan domain otomatis dimatikan${NC}"
                else
                    jq '.auto_display = true' "$DOMAIN_FILE" > tmp.json && mv tmp.json "$DOMAIN_FILE"
                    echo -e "${GREEN}✓ Tampilan domain otomatis diaktifkan${NC}"
                fi
                sleep 1
                ;;
            4)
                domain=$(get_domain)
                if [ ! -z "$domain" ]; then
                    echo -e "\n${CYAN}Testing domain: $domain${NC}"
                    echo -e "${YELLOW}Melakukan ping...${NC}"
                    if ping -c 2 "$domain" &>/dev/null; then
                        echo -e "${GREEN}✓ Domain dapat diakses${NC}"
                    else
                        echo -e "${YELLOW}⚠ Domain tidak merespon ping (mungkin normal jika tidak mengizinkan ping)${NC}"
                    fi
                    
                    echo -e "\n${CYAN}Informasi Domain:${NC}"
                    echo -e "Domain lengkap: $domain"
                    echo -e "IP Server: $(get_server_ip)"
                else
                    echo -e "${RED}❌ Domain belum dikonfigurasi${NC}"
                fi
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            5)
                break
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Fungsi untuk backup config
backup_config() {
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    cp "$CONFIG_FILE" "${CONFIG_FILE}.backup_${timestamp}"
    echo -e "${YELLOW}Backup created: ${CONFIG_FILE}.backup_${timestamp}${NC}" >> "$LOG_FILE"
}

# Fungsi inisialisasi database user
init_user_db() {
    if [ ! -f "$USER_DB" ]; then
        echo -e "${YELLOW}Creating user database...${NC}"
        cat > "$USER_DB" << EOF
{
    "users": {},
    "settings": {
        "max_devices_per_user": 3,
        "auto_cleanup_days": 7,
        "trial_duration_minutes": 35,
        "enable_trial": true
    }
}
EOF
        echo -e "${GREEN}✓ User database created${NC}"
    fi
}

# Fungsi untuk memastikan struktur config.json benar
ensure_config_structure() {
    if [ ! -f "$CONFIG_FILE" ]; then
        echo -e "${YELLOW}Creating new config file...${NC}"
        cat > "$CONFIG_FILE" << EOF
{
    "listen": ":5667",
    "cert": "/etc/zivpn/zivpn.crt",
    "key": "/etc/zivpn/zivpn.key",
    "obfs": "zivpn",
    "auth": {
        "mode": "passwords",
        "config": []
    }
}
EOF
        echo -e "${GREEN}✓ Config file created${NC}"
    fi
}

# Install dependensi
install_dependencies() {
    if ! command -v jq &>/dev/null; then
        echo -e "${YELLOW}Installing jq...${NC}"
        apt-get update && apt-get install -y jq
        echo -e "${GREEN}✓ jq berhasil diinstall${NC}"
    fi
    
    if ! command -v bc &>/dev/null; then
        echo -e "${YELLOW}Installing bc...${NC}"
        apt-get install -y bc
        echo -e "${GREEN}✓ bc berhasil diinstall${NC}"
    fi
    
    if ! command -v curl &>/dev/null; then
        echo -e "${YELLOW}Installing curl...${NC}"
        apt-get install -y curl
        echo -e "${GREEN}✓ curl berhasil diinstall${NC}"
    fi
    
    if ! command -v git &>/dev/null; then
        echo -e "${YELLOW}Installing git...${NC}"
        apt-get install -y git
        echo -e "${GREEN}✓ git berhasil diinstall${NC}"
    fi
}

# Restart service
restart_service() {
    echo -e "\n${YELLOW}Merestart service $SERVICE...${NC}"
    systemctl restart $SERVICE
    if systemctl is-active --quiet $SERVICE; then
        echo -e "${GREEN}✓ Service $SERVICE berhasil direstart${NC}"
        return 0
    else
        echo -e "${RED}❌ Gagal restart service $SERVICE${NC}"
        return 1
    fi
}

# ==============================
# FUNGSI EXPIRY & TRIAL - DIPERBAIKI
# ==============================

# Fungsi untuk cek masa aktif - DIPERBAIKI
check_expiry() {
    local username=$1
    
    # Cek apakah user ada
    if ! jq -e ".users.\"$username\"" "$USER_DB" >/dev/null 2>&1; then
        echo "user_not_found"
        return
    fi
    
    local expiry_date=$(jq -r ".users.\"$username\".expiry_date" "$USER_DB" 2>/dev/null)
    local is_trial=$(jq -r ".users.\"$username\".is_trial // false" "$USER_DB" 2>/dev/null)
    
    if [ "$expiry_date" = "null" ] || [ -z "$expiry_date" ]; then
        echo "no_expiry"
        return
    fi
    
    if [ "$expiry_date" = "unlimited" ]; then
        echo "no_expiry"
        return
    fi
    
    # Konversi tanggal ke timestamp
    local current_timestamp=$(date +%s)
    
    # Coba format tanggal dengan format lengkap
    local expiry_timestamp=$(date -d "$expiry_date" "+%s" 2>/dev/null)
    
    # Jika gagal, coba format lain
    if [ $? -ne 0 ] || [ -z "$expiry_timestamp" ]; then
        # Coba format YYYY-MM-DD HH:MM:SS
        expiry_timestamp=$(date -d "$expiry_date" "+%s" 2>/dev/null)
    fi
    
    # Jika masih gagal, return invalid
    if [ $? -ne 0 ] || [ -z "$expiry_timestamp" ]; then
        echo "invalid_date"
        return
    fi
    
    # Hitung selisih waktu
    local diff_seconds=$((expiry_timestamp - current_timestamp))
    
    if [ $diff_seconds -le 0 ]; then
        if [ "$is_trial" = "true" ]; then
            echo "trial_expired"
        else
            echo "expired"
        fi
    else
        if [ "$is_trial" = "true" ]; then
            # Untuk trial, tampilkan dalam menit
            local minutes_left=$((diff_seconds / 60))
            if [ $minutes_left -lt 1 ]; then
                echo "trial_expired"
            else
                echo "trial_${minutes_left}"
            fi
        else
            # Untuk regular user, tampilkan dalam hari
            local days_left=$((diff_seconds / 86400))
            if [ $days_left -lt 1 ]; then
                echo "expired"
            else
                echo "$days_left"
            fi
        fi
    fi
}

# Fungsi untuk membuat user trial - DIPERBAIKI
create_trial_user() {
    local username="trial_$(date +%s%N | md5sum | head -c 8)"
    local password=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 12 | head -n 1)
    local trial_minutes=$(jq -r '.settings.trial_duration_minutes // 35' "$USER_DB" 2>/dev/null)
    
    if [ -z "$trial_minutes" ] || [ "$trial_minutes" = "null" ]; then
        trial_minutes=35
    fi
    
    local expiry_date=$(date -d "+$trial_minutes minutes" "+%Y-%m-%d %H:%M:%S")
    
    # Backup sebelum modifikasi
    backup_config
    
    # Tambah password ke config
    if jq --arg p "$password" '.auth.config += [$p]' "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"; then
        # Tambah ke database user
        current_date=$(date "+%Y-%m-%d %H:%M:%S")
        jq --arg user "$username" \
           --arg pass "$password" \
           --arg expiry "$expiry_date" \
           --arg created "$current_date" \
           '.users[$user] = {
               password: $pass,
               created_date: $created,
               expiry_date: $expiry,
               last_login: null,
               device_count: 0,
               is_active: true,
               is_trial: true,
               user_type: "trial"
           }' "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
        
        echo -e "\n${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}${BOLD}                    TRIAL USER BERHASIL DIBUAT!                ${NC}"
        echo -e "${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
        
        # Ambil IP server dan domain
        SERVER_IP=$(get_server_ip)
        DOMAIN=$(get_domain)
        
        # Tampilkan informasi
        echo -e "\n${BG_GREEN}${BOLD}   INFORMASI TRIAL USER   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}Username      : ${GREEN}${BOLD}$username${NC}"
        echo -e "${CYAN}Password      : ${GREEN}${BOLD}$password${NC}"
        echo -e "${CYAN}Masa Aktif    : ${GREEN}${BOLD}$trial_minutes Menit${NC}"
        echo -e "${CYAN}Expired Date  : ${GREEN}${BOLD}$expiry_date${NC}"
        echo -e "${CYAN}Tipe User     : ${GREEN}${BOLD}Trial${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        echo -e "\n${BG_BLUE}${BOLD}   INFORMASI KONEKSI   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}IP Server     : ${GREEN}${BOLD}$SERVER_IP${NC}"
        if [ ! -z "$DOMAIN" ] && [ "$(jq -r '.auto_display // true' "$DOMAIN_FILE" 2>/dev/null)" = "true" ]; then
            echo -e "${CYAN}Domain        : ${GREEN}${BOLD}$DOMAIN${NC}"
        fi
        echo -e "${CYAN}Port          : ${GREEN}${BOLD}5667${NC}"
        echo -e "${CYAN}Protocol      : ${GREEN}${BOLD}UDP${NC}"
        echo -e "${CYAN}OBFS          : ${GREEN}${BOLD}zivpn${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        echo -e "\n${YELLOW}⚠️  PERINGATAN: User trial akan otomatis dihapus setelah $trial_minutes menit!${NC}"
        
        # Restart service
        restart_service
        
        # Kirim notifikasi trial
        send_trial_notification "$username" "$password" "$trial_minutes"
        
        return 0
    else
        echo -e "\n${RED}❌ Gagal membuat user trial!${NC}"
        return 1
    fi
}

# Fungsi untuk renew akun
renew_user() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}🔄 RENEW USER${NC}\n"
        
        # Cek apakah ada user
        user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "${YELLOW}Tidak ada user yang terdaftar${NC}"
            sleep 2
            return
        fi
        
        echo -e "${CYAN}Daftar User yang dapat di-renew:${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        local i=1
        declare -A user_array
        
        jq -r '.users | to_entries[] | "\(.key)|\(.value.expiry_date)|\(.value.is_trial // false)"' "$USER_DB" 2>/dev/null | while IFS='|' read username expiry is_trial; do
            if [ "$is_trial" = "false" ]; then
                status=$(check_expiry "$username")
                if [ "$status" = "expired" ]; then
                    echo -e "${RED}$i. $username (EXPIRED)${NC}"
                    user_array[$i]="$username"
                    ((i++))
                elif [[ "$status" =~ ^[0-9]+$ ]] && [ $status -lt 3 ]; then
                    echo -e "${YELLOW}$i. $username ($status hari lagi)${NC}"
                    user_array[$i]="$username"
                    ((i++))
                elif [ "$status" = "no_expiry" ]; then
                    echo -e "${GREEN}$i. $username (UNLIMITED)${NC}"
                elif [[ "$status" =~ ^[0-9]+$ ]]; then
                    echo -e "${GREEN}$i. $username ($status hari lagi)${NC}"
                fi
            fi
        done
        
        if [ ${#user_array[@]} -eq 0 ]; then
            echo -e "${YELLOW}Tidak ada user yang perlu di-renew${NC}"
            sleep 2
            return
        fi
        
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}\n"
        
        read -p "$(echo -e ${YELLOW}"Masukkan nomor user yang ingin di-renew (atau 'q' untuk kembali): "${NC})" choice
        
        if [ "$choice" = "q" ] || [ "$choice" = "Q" ]; then
            return
        fi
        
        if [[ ! "$choice" =~ ^[0-9]+$ ]] || [ -z "${user_array[$choice]}" ]; then
            echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
            sleep 2
            continue
        fi
        
        username="${user_array[$choice]}"
        
        # Cek apakah user trial
        is_trial=$(jq -r ".users.\"$username\".is_trial" "$USER_DB" 2>/dev/null)
        if [ "$is_trial" = "true" ]; then
            echo -e "\n${RED}❌ User trial tidak dapat di-renew!${NC}"
            sleep 2
            continue
        fi
        
        # Tampilkan informasi user
        current_expiry=$(jq -r ".users.\"$username\".expiry_date" "$USER_DB")
        echo -e "\n${CYAN}Informasi User:${NC}"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        echo -e "Username      : $username"
        echo -e "Expiry Date   : $current_expiry"
        echo -e "Status        : $(check_expiry "$username")"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        
        echo -e "\n${CYAN}Pilih Periode Renew:${NC}"
        echo -e "${GREEN}1. ${NC}7 Hari"
        echo -e "${GREEN}2. ${NC}30 Hari"
        echo -e "${GREEN}3. ${NC}90 Hari"
        echo -e "${GREEN}4. ${NC}1 Tahun"
        echo -e "${GREEN}5. ${NC}Custom (hari)"
        echo -e "${GREEN}6. ${NC}Batal"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-6]: "${NC})" period_choice
        
        case $period_choice in
            1)
                days=7
                ;;
            2)
                days=30
                ;;
            3)
                days=90
                ;;
            4)
                days=365
                ;;
            5)
                read -p "$(echo -e ${YELLOW}"Masukkan jumlah hari: "${NC})" custom_days
                if [[ "$custom_days" =~ ^[0-9]+$ ]] && [ "$custom_days" -gt 0 ]; then
                    days=$custom_days
                else
                    echo -e "\n${RED}❌ Jumlah hari tidak valid!${NC}"
                    sleep 2
                    continue
                fi
                ;;
            6)
                echo -e "${YELLOW}Renew dibatalkan${NC}"
                return
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 2
                continue
                ;;
        esac
        
        # Hitung tanggal expiry baru
        if [ "$current_expiry" = "unlimited" ]; then
            # Jika unlimited, mulai dari sekarang
            new_expiry=$(date -d "+$days days" "+%Y-%m-%d")
        else
            # Cek apakah sudah expired
            status=$(check_expiry "$username")
            if [ "$status" = "expired" ]; then
                # Jika expired, mulai dari sekarang
                new_expiry=$(date -d "+$days days" "+%Y-%m-%d")
            else
                # Jika masih aktif, tambahkan dari expiry date lama
                if date -d "$current_expiry" >/dev/null 2>&1; then
                    new_expiry=$(date -d "$current_expiry + $days days" "+%Y-%m-%d")
                else
                    # Jika format tanggal salah, mulai dari sekarang
                    new_expiry=$(date -d "+$days days" "+%Y-%m-%d")
                fi
            fi
        fi
        
        echo -e "\n${YELLOW}⚠️  Konfirmasi Renew${NC}"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        echo -e "${CYAN}Username        : ${GREEN}$username${NC}"
        echo -e "${CYAN}Periode         : ${GREEN}$days hari${NC}"
        echo -e "${CYAN}Expiry Lama     : ${YELLOW}$current_expiry${NC}"
        echo -e "${CYAN}Expiry Baru     : ${GREEN}$new_expiry${NC}"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        
        read -p "$(echo -e ${YELLOW}"Lanjutkan renew? (y/n): "${NC})" confirm
        
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            echo -e "${YELLOW}Renew dibatalkan${NC}"
            sleep 1
            continue
        fi

        # Update expiry date
        jq --arg user "$username" \
           --arg expiry "$new_expiry" \
           '.users[$user].expiry_date = $expiry' "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
        
        # Update last renew date
        jq --arg user "$username" \
           --arg renew "$(date "+%Y-%m-%d %H:%M:%S")" \
           '.users[$user].last_renew = $renew' "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
        
        echo -e "\n${GREEN}✓ User '$username' berhasil direnew!${NC}"
        echo -e "${CYAN}Expiry baru: ${GREEN}$new_expiry${NC}"
        
        # Kirim notifikasi renew
        send_renew_notification "$username" "$days" "$new_expiry"
        
        echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
        read
        break
    done
}

# Fungsi untuk auto hapus user expired - DIPERBAIKI
auto_cleanup_expired() {
    echo -e "${YELLOW}🔄 Running auto cleanup for expired users...${NC}"
    local count=0
    local trial_count=0
    
    # Buat array dari users
    local users=()
    while IFS= read -r line; do
        users+=("$line")
    done < <(jq -r '.users | keys[]' "$USER_DB" 2>/dev/null)
    
    for username in "${users[@]}"; do
        status=$(check_expiry "$username")
        
        if [ "$status" = "expired" ] || [ "$status" = "trial_expired" ]; then
            # Dapatkan tipe user
            is_trial=$(jq -r ".users.\"$username\".is_trial // false" "$USER_DB" 2>/dev/null)
            
            if [ "$is_trial" = "true" ]; then
                echo -e "${YELLOW}Deleting expired trial user: $username${NC}"
                ((trial_count++))
            else
                echo -e "${RED}Deleting expired user: $username${NC}"
                ((count++))
            fi
            
            # Remove password from config
            local password=$(jq -r ".users.\"$username\".password" "$USER_DB" 2>/dev/null)
            if [ ! -z "$password" ] && [ "$password" != "null" ]; then
                jq "del(.auth.config[] | select(. == \"$password\"))" "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"
            fi
            
            # Remove from user DB
            jq "del(.users.\"$username\")" "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
            
            echo "$(date): User $username expired and deleted" >> "$LOG_FILE"
        fi
    done
    
    if [ $count -gt 0 ] || [ $trial_count -gt 0 ]; then
        restart_service
        echo -e "${GREEN}✓ Cleaned up $count expired users and $trial_count trial users${NC}"
    else
        echo -e "${GREEN}✓ No expired users found${NC}"
    fi
}

# Fungsi untuk hapus user trial secara manual
cleanup_trial_users() {
    show_header
    echo -e "${CYAN}${BOLD}🧹 CLEANUP TRIAL USERS${NC}\n"
    
    echo -e "${YELLOW}Membersihkan semua user trial yang expired...${NC}"
    
    local trial_count=0
    local users=()
    while IFS= read -r line; do
        users+=("$line")
    done < <(jq -r '.users | keys[]' "$USER_DB" 2>/dev/null)
    
    for username in "${users[@]}"; do
        is_trial=$(jq -r ".users.\"$username\".is_trial // false" "$USER_DB" 2>/dev/null)
        if [ "$is_trial" = "true" ]; then
            status=$(check_expiry "$username")
            if [ "$status" = "trial_expired" ]; then
                echo -e "${YELLOW}Deleting trial user: $username${NC}"
                
                # Remove password from config
                local password=$(jq -r ".users.\"$username\".password" "$USER_DB" 2>/dev/null)
                if [ ! -z "$password" ] && [ "$password" != "null" ]; then
                    jq "del(.auth.config[] | select(. == \"$password\"))" "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"
                fi
                
                # Remove from user DB
                jq "del(.users.\"$username\")" "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
                
                ((trial_count++))
            fi
        fi
    done
    
    if [ $trial_count -gt 0 ]; then
        restart_service
        echo -e "${GREEN}✓ Cleaned up $trial_count trial users${NC}"
    else
        echo -e "${GREEN}✓ No expired trial users found${NC}"
    fi
    
    echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
    read
}

# ==============================
# FUNGSI NOTIFIKASI
# ==============================

# Fungsi untuk kirim notifikasi trial
send_trial_notification() {
    local username=$1
    local password=$2
    local duration=$3
    
    # Cek apakah notifikasi Telegram aktif
    if [ -f "$BACKUP_CONFIG" ] && [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_new_user' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        local domain=$(get_domain)
        
        local message="🎫 TRIAL USER BARU DIBUAT\n\n"
        message+="📱 Username: $username\n"
        message+="🔑 Password: $password\n"
        message+="⏱️  Durasi: $duration menit\n"
        message+="📅 Expired: $(date -d "+$duration minutes" "+%Y-%m-%d %H:%M:%S")\n"
        
        if [ ! -z "$domain" ]; then
            message+="\n🌐 Domain: $domain\n"
        fi
        message+="🖥️  Server: $server_ip\n"
        message+="🔌 Port: 5667\n"
        message+="🕐 Waktu: $(date)\n\n"
        message+="⚠️  User trial akan otomatis dihapus setelah $duration menit!"
        
        send_telegram_notification "$message"
    fi
}

# Fungsi untuk kirim notifikasi renew
send_renew_notification() {
    local username=$1
    local days=$2
    local expiry=$3
    
    # Cek apakah notifikasi Telegram aktif
    if [ -f "$BACKUP_CONFIG" ] && [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_new_user' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        local domain=$(get_domain)
        
        local message="🔄 USER DI-RENEW\n\n"
        message+="📱 Username: $username\n"
        message+="📅 Periode: $days hari\n"
        message+="⏰ Expiry Baru: $expiry\n"
        
        if [ ! -z "$domain" ]; then
            message+="\n🌐 Domain: $domain\n"
        fi
        message+="🖥️  Server: $server_ip\n"
        message+="🔌 Port: 5667\n"
        message+="🕐 Waktu: $(date)\n\n"
        message+="✅ User berhasil direnew!"
        
        send_telegram_notification "$message"
    fi
}

# Fungsi untuk mengirim notifikasi ke Telegram
send_telegram_notification() {
    local message="$1"
    
    if [ -f "$BACKUP_CONFIG" ]; then
        local bot_token=$(jq -r '.telegram.bot_token' "$BACKUP_CONFIG" 2>/dev/null)
        local chat_id=$(jq -r '.telegram.chat_id' "$BACKUP_CONFIG" 2>/dev/null)
        
        if [ "$bot_token" != "null" ] && [ "$chat_id" != "null" ] && \
           [ ! -z "$bot_token" ] && [ ! -z "$chat_id" ] && \
           [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
            
            # Encode message untuk URL
            local encoded_message=$(echo -e "$message" | sed 's/ /%20/g; s/\n/%0A/g')
            
            # Kirim via curl
            curl -s -X POST "https://api.telegram.org/bot${bot_token}/sendMessage" \
                -d "chat_id=${chat_id}" \
                -d "text=${encoded_message}" \
                -d "parse_mode=HTML" > /dev/null 2>&1
                
            return $?
        fi
    fi
    
    return 1
}

# ==============================
# FUNGSI UTAMA USER MANAGEMENT
# ==============================

# Tambah user baru dengan masa aktif
add_user() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}➕ TAMBAH USER BARU${NC}\n"
        
        read -p "$(echo -e ${YELLOW}"Masukkan Username: "${NC})" username
        
        if [ -z "$username" ]; then
            echo -e "\n${RED}❌ Username tidak boleh kosong!${NC}"
            sleep 2
            continue
        fi
        
        # Cek apakah username sudah ada
        if jq -e ".users.\"$username\"" "$USER_DB" >/dev/null 2>&1; then
            echo -e "\n${RED}❌ Username '$username' sudah ada!${NC}"
            sleep 2
            continue
        fi
        
        read -p "$(echo -e ${YELLOW}"Masukkan Password: "${NC})" password
        
        if [ -z "$password" ]; then
            echo -e "\n${RED}❌ Password tidak boleh kosong!${NC}"
            sleep 2
            continue
        fi
        
        echo -e "\n${CYAN}Pilih Tipe User:${NC}"
        echo -e "${GREEN}1. ${NC}User Regular"
        echo -e "${GREEN}2. ${NC}User Trial (35 menit)"
        echo -e "${GREEN}3. ${NC}Kembali"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-3]: "${NC})" type_choice
        
        case $type_choice in
            1)
                echo -e "\n${CYAN}Pilih Masa Aktif:${NC}"
                echo -e "${GREEN}1. ${NC}7 Hari"
                echo -e "${GREEN}2. ${NC}30 Hari"
                echo -e "${GREEN}3. ${NC}90 Hari"
                echo -e "${GREEN}4. ${NC}1 Tahun"
                echo -e "${GREEN}5. ${NC}Unlimited"
                echo -e "${GREEN}6. ${NC}Custom"
                
                read -p "$(echo -e ${YELLOW}"Pilih [1-6]: "${NC})" period_choice
                
                case $period_choice in
                    1)
                        expiry_date=$(date -d "+7 days" "+%Y-%m-%d")
                        period="7 Hari"
                        user_type="regular"
                        ;;
                    2)
                        expiry_date=$(date -d "+30 days" "+%Y-%m-%d")
                        period="30 Hari"
                        user_type="regular"
                        ;;
                    3)
                        expiry_date=$(date -d "+90 days" "+%Y-%m-%d")
                        period="90 Hari"
                        user_type="regular"
                        ;;
                    4)
                        expiry_date=$(date -d "+1 year" "+%Y-%m-%d")
                        period="1 Tahun"
                        user_type="regular"
                        ;;
                    5)
                        expiry_date="unlimited"
                        period="Unlimited"
                        user_type="regular"
                        ;;
                    6)
                        read -p "$(echo -e ${YELLOW}"Masukkan jumlah hari: "${NC})" custom_days
                        if [[ "$custom_days" =~ ^[0-9]+$ ]] && [ "$custom_days" -gt 0 ]; then
                            expiry_date=$(date -d "+$custom_days days" "+%Y-%m-%d")
                            period="$custom_days Hari"
                            user_type="regular"
                        else
                            echo -e "\n${RED}❌ Jumlah hari tidak valid!${NC}"
                            sleep 2
                            continue
                        fi
                        ;;
                    *)
                        echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                        sleep 2
                        continue
                        ;;
                esac
                is_trial=false
                ;;
            2)
                trial_minutes=$(jq -r '.settings.trial_duration_minutes // 35' "$USER_DB" 2>/dev/null)
                expiry_date=$(date -d "+$trial_minutes minutes" "+%Y-%m-%d %H:%M:%S")
                period="$trial_minutes Menit"
                user_type="trial"
                is_trial=true
                ;;
            3)
                return
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 2
                continue
                ;;
        esac
        
        # Backup sebelum modifikasi
        backup_config
        
        # Tambah password ke config
        if jq --arg p "$password" '.auth.config += [$p]' "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"; then
            # Tambah ke database user
            current_date=$(date "+%Y-%m-%d %H:%M:%S")
            jq --arg user "$username" \
               --arg pass "$password" \
               --arg expiry "$expiry_date" \
               --arg created "$current_date" \
               --argjson trial "$is_trial" \
               --arg type "$user_type" \
               '.users[$user] = {
                   password: $pass,
                   created_date: $created,
                   expiry_date: $expiry,
                   last_login: null,
                   device_count: 0,
                   is_active: true,
                   is_trial: $trial,
                   user_type: $type
               }' "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
            
            echo -e "\n${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
            echo -e "${GREEN}${BOLD}                    USER BERHASIL DITAMBAHKAN!                ${NC}"
            echo -e "${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
            
            # Ambil IP server dan domain
            SERVER_IP=$(get_server_ip)
            DOMAIN=$(get_domain)
            
            # Tampilkan informasi
            echo -e "\n${BG_GREEN}${BOLD}   INFORMASI USER   ${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            echo -e "${CYAN}Username      : ${GREEN}${BOLD}$username${NC}"
            echo -e "${CYAN}Password      : ${GREEN}${BOLD}$password${NC}"
            echo -e "${CYAN}Tipe User     : ${GREEN}${BOLD}$user_type${NC}"
            echo -e "${CYAN}Masa Aktif    : ${GREEN}${BOLD}$period${NC}"
            
            if [ "$expiry_date" != "unlimited" ]; then
                echo -e "${CYAN}Expired Date  : ${GREEN}${BOLD}$expiry_date${NC}"
            fi
            
            echo -e "${CYAN}Tanggal Buat  : ${GREEN}${BOLD}$current_date${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            
            echo -e "\n${BG_BLUE}${BOLD}   INFORMASI KONEKSI   ${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            echo -e "${CYAN}IP Server     : ${GREEN}${BOLD}$SERVER_IP${NC}"
            if [ ! -z "$DOMAIN" ] && [ "$(jq -r '.auto_display // true' "$DOMAIN_FILE" 2>/dev/null)" = "true" ]; then
                echo -e "${CYAN}Domain        : ${GREEN}${BOLD}$DOMAIN${NC}"
            fi
            echo -e "${CYAN}Port          : ${GREEN}${BOLD}5667${NC}"
            echo -e "${CYAN}Protocol      : ${GREEN}${BOLD}UDP${NC}"
            echo -e "${CYAN}OBFS          : ${GREEN}${BOLD}zivpn${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            
            echo -e "\n${YELLOW}💡 Catatan untuk customer:${NC}"
            echo -e "${PURPLE}• Username: ${BOLD}kosongkan${NC}"
            echo -e "${PURPLE}• Password: ${BOLD}$password${NC}"
            echo -e "${PURPLE}• Max perangkat: ${BOLD}$(jq -r '.settings.max_devices_per_user' "$USER_DB" 2>/dev/null || echo "3")${NC}"
            
            # Restart service
            restart_service
            
            echo -e "\n${YELLOW}📋 Total user sekarang: ${GREEN}$(jq '.users | length' "$USER_DB")${NC}"
            
            # Kirim notifikasi
            if [ "$user_type" = "trial" ]; then
                send_trial_notification "$username" "$password" "$trial_minutes"
            else
                send_new_user_notification "$username" "$password" "$expiry_date" "$period"
            fi
            
            read -p "$(echo -e ${YELLOW}"Tambahkan user lagi? (y/n): "${NC})" add_more
            if [[ ! "$add_more" =~ ^[Yy]$ ]]; then
                break
            fi
        else
            echo -e "\n${RED}❌ Gagal menambahkan user!${NC}"
            sleep 2
        fi
    done
}

# Hapus user
delete_user() {
    while true; do
        show_header
        echo -e "${RED}${BOLD}🗑️  HAPUS USER${NC}\n"
        
        # Cek apakah ada user
        user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "${YELLOW}Tidak ada user yang terdaftar${NC}"
            sleep 2
            return
        fi
        
        echo -e "${CYAN}Daftar User:${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        local i=1
        declare -A user_array
        
        jq -r '.users | to_entries[] | "\(.key)|\(.value.expiry_date)|\(.value.is_trial // false)"' "$USER_DB" 2>/dev/null | while IFS='|' read username expiry is_trial; do
            status=$(check_expiry "$username")
            user_array[$i]="$username"
            
            if [ "$status" = "expired" ] || [ "$status" = "trial_expired" ]; then
                if [ "$is_trial" = "true" ]; then
                    echo -e "${RED}$i. $username (TRIAL EXPIRED)${NC}"
                else
                    echo -e "${RED}$i. $username (EXPIRED)${NC}"
                fi
            elif [ "$status" = "no_expiry" ]; then
                echo -e "${GREEN}$i. $username (ACTIVE)${NC}"
            elif [[ "$status" =~ ^trial_[0-9]+$ ]]; then
                minutes_left=$(echo "$status" | cut -d'_' -f2)
                echo -e "${CYAN}$i. $username (TRIAL - $minutes_left menit)${NC}"
            elif [[ "$status" =~ ^[0-9]+$ ]]; then
                echo -e "${GREEN}$i. $username ($status hari lagi)${NC}"
            else
                echo -e "${YELLOW}$i. $username${NC}"
            fi
            ((i++))
        done
        
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}\n"
        
        read -p "$(echo -e ${YELLOW}"Masukkan nomor user yang ingin dihapus (atau 'q' untuk kembali): "${NC})" choice
        
        if [ "$choice" = "q" ] || [ "$choice" = "Q" ]; then
            return
        fi
        
        if [[ ! "$choice" =~ ^[0-9]+$ ]] || [ -z "${user_array[$choice]}" ]; then
            echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
            sleep 2
            continue
        fi
        
        username="${user_array[$choice]}"
        
        # Cek apakah username ada
        if ! jq -e ".users.\"$username\"" "$USER_DB" >/dev/null 2>&1; then
            echo -e "\n${RED}❌ Username '$username' tidak ditemukan!${NC}"
            sleep 2
            continue
        fi
        
        # Dapatkan password user
        password=$(jq -r ".users.\"$username\".password" "$USER_DB")
        
        echo -e "\n${YELLOW}⚠️  Konfirmasi Penghapusan${NC}"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        echo -e "${RED}User yang akan dihapus:${NC}"
        echo -e "${RED}Username: ${BOLD}$username${NC}"
        echo -e "${RED}Password: ${BOLD}$password${NC}"
        echo -e "${BOLD}────────────────────────────────────${NC}"
        
        read -p "$(echo -e ${YELLOW}"Yakin ingin menghapus? (y/n): "${NC})" confirm
        
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            echo -e "${YELLOW}Penghapusan dibatalkan${NC}"
            sleep 1
            continue
        fi

        # Backup sebelum modifikasi
        backup_config
        
        # Hapus password dari config
        jq "del(.auth.config[] | select(. == \"$password\"))" "$CONFIG_FILE" > tmp.json && mv tmp.json "$CONFIG_FILE"
        
        # Hapus dari database user
        jq "del(.users.\"$username\")" "$USER_DB" > tmp.json && mv tmp.json "$USER_DB"
        
        echo -e "\n${GREEN}✓ User '$username' berhasil dihapus!${NC}"
        
        # Restart service
        restart_service
        
        echo -e "\n${YELLOW}📋 Total user tersisa: ${GREEN}$(jq '.users | length' "$USER_DB")${NC}"
        
        read -p "$(echo -e ${YELLOW}"Hapus user lagi? (y/n): "${NC})" delete_more
        if [[ ! "$delete_more" =~ ^[Yy]$ ]]; then
            break
        fi
    done
}

# Lihat semua user
list_users() {
    while true; do
        show_header
        echo -e "${BLUE}${BOLD}📋 DAFTAR SEMUA USER${NC}\n"
        
        # Cek apakah ada user
        user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "${YELLOW}Belum ada user terdaftar${NC}"
        else
            # Ambil IP server dan domain
            SERVER_IP=$(get_server_ip)
            DOMAIN=$(get_domain)
            
            echo -e "${BG_PURPLE}${BOLD}   INFORMASI SERVER   ${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            echo -e "${CYAN}IP Server     : ${GREEN}${BOLD}$SERVER_IP${NC}"
            if [ ! -z "$DOMAIN" ] && [ "$(jq -r '.auto_display // true' "$DOMAIN_FILE" 2>/dev/null)" = "true" ]; then
                echo -e "${CYAN}Domain        : ${GREEN}${BOLD}$DOMAIN${NC}"
            fi
            echo -e "${CYAN}Port          : ${GREEN}${BOLD}5667${NC}"
            echo -e "${CYAN}Total User    : ${GREEN}${BOLD}$user_count${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}\n"
            
            echo -e "${CYAN}${BOLD}Daftar User:${NC}"
            echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
            
            printf "%-20s %-12s %-15s %-12s %-10s\n" "Username" "Tipe" "Created" "Expiry" "Status"
            echo -e "${BOLD}────────────────────────────────────────────────────────${NC}"
            
            jq -r '.users | to_entries[] | "\(.key)|\(.value.user_type)|\(.value.created_date)|\(.value.expiry_date)|\(.value.is_trial // false)"' "$USER_DB" 2>/dev/null | while IFS='|' read username user_type created expiry is_trial; do
                status=$(check_expiry "$username")
                
                # Tentukan warna untuk tipe user
                if [ "$user_type" = "trial" ]; then
                    type_text="${CYAN}TRIAL${NC}"
                else
                    type_text="${GREEN}$user_type${NC}"
                fi
                
                # Tentukan status
                if [ "$status" = "expired" ]; then
                    status_text="${RED}EXPIRED${NC}"
                    expiry_text="${RED}$expiry${NC}"
                elif [ "$status" = "trial_expired" ]; then
                    status_text="${RED}TRIAL EXPIRED${NC}"
                    expiry_text="${RED}$expiry${NC}"
                elif [ "$status" = "no_expiry" ]; then
                    status_text="${GREEN}ACTIVE${NC}"
                    expiry_text="${GREEN}Unlimited${NC}"
                elif [[ "$status" =~ ^trial_[0-9]+$ ]]; then
                    minutes_left=$(echo "$status" | cut -d'_' -f2)
                    status_text="${CYAN}TRIAL ($minutes_leftm)${NC}"
                    expiry_text="${CYAN}$expiry${NC}"
                elif [[ "$status" =~ ^[0-9]+$ ]]; then
                    status_text="${GREEN}ACTIVE${NC}"
                    expiry_text="${GREEN}$status days${NC}"
                else
                    status_text="${YELLOW}$status${NC}"
                    expiry_text="${YELLOW}$expiry${NC}"
                fi
                
                printf "%-20s %-20s %-15s %-15s %-30s\n" "$username" "$(echo -e "$type_text")" "$created" "$(echo -e "$expiry_text")" "$(echo -e "$status_text")"
            done
            
            echo -e "\n${YELLOW}📊 Statistik:${NC}"
            echo -e "${BOLD}────────────────────────────────────${NC}"
            
            # Hitung statistik
            regular_count=0
            trial_count=0
            active_count=0
            expired_count=0
            trial_active_count=0
            trial_expired_count=0
            
            jq -r '.users | keys[]' "$USER_DB" 2>/dev/null | while read username; do
                user_type=$(jq -r ".users.\"$username\".user_type" "$USER_DB" 2>/dev/null)
                is_trial=$(jq -r ".users.\"$username\".is_trial" "$USER_DB" 2>/dev/null)
                status=$(check_expiry "$username")
                
                if [ "$user_type" = "trial" ] || [ "$is_trial" = "true" ]; then
                    ((trial_count++))
                    if [ "$status" = "trial_expired" ]; then
                        ((trial_expired_count++))
                    else
                        ((trial_active_count++))
                    fi
                else
                    ((regular_count++))
                    if [ "$status" = "expired" ]; then
                        ((expired_count++))
                    else
                        ((active_count++))
                    fi
                fi
            done
            
            echo -e "${CYAN}User Regular  : ${GREEN}$regular_count${NC}"
            echo -e "${CYAN}User Trial    : ${CYAN}$trial_count${NC}"
            echo -e "${CYAN}  - Aktif     : ${GREEN}$trial_active_count${NC}"
            echo -e "${CYAN}  - Expired   : ${RED}$trial_expired_count${NC}"
            echo -e "${CYAN}User Aktif    : ${GREEN}$((active_count + trial_active_count))${NC}"
            echo -e "${CYAN}User Expired  : ${RED}$((expired_count + trial_expired_count))${NC}"
            echo -e "${BOLD}────────────────────────────────────${NC}"
        fi
        
        echo -e "\n${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}1. ${NC}Tambah User Baru"
        echo -e "${GREEN}2. ${NC}Buat Trial User"
        echo -e "${RED}3. ${NC}Hapus User"
        echo -e "${CYAN}4. ${NC}Renew User"
        echo -e "${YELLOW}5. ${NC}Auto Cleanup Expired"
        echo -e "${PURPLE}6. ${NC}Cleanup Trial Users"
        echo -e "${BLUE}7. ${NC}Kembali ke Menu Utama"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${PURPLE}"Pilih [1-7]: "${NC})" choice
        
        case $choice in
            1) add_user ;;
            2) 
                create_trial_user
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            3) delete_user ;;
            4) renew_user ;;
            5) 
                auto_cleanup_expired
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            6) cleanup_trial_users ;;
            7) break ;;
            *) 
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# ==============================
# FUNGSI BACKUP & RESTORE (DARI SCRIPT ANDA)
# ==============================

# Fungsi untuk inisialisasi konfigurasi backup
init_backup_config() {
    if [ ! -f "$BACKUP_CONFIG" ]; then
        echo -e "${YELLOW}Membuat konfigurasi backup...${NC}"
        mkdir -p "$BACKUP_DIR"
        
        cat > "$BACKUP_CONFIG" << EOF
{
    "backup": {
        "enabled": false,
        "auto_backup": false,
        "backup_interval": "daily",
        "keep_local_backups": 7,
        "last_backup": null,
        "github_enabled": false
    },
    "telegram": {
        "enabled": false,
        "bot_token": "none",
        "chat_id": "",
        "notify_on_new_user": true,
        "notify_on_backup": true
    },
    "github": {
        "token": "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",
        "username": "rahmatstorevpn",
        "repo": "project",
        "backup_dir": "zivpn_backups"
    }
}
EOF
        echo -e "${GREEN}✓ Konfigurasi backup dibuat${NC}"
    fi
}

# Fungsi untuk membuat backup
create_backup() {
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="zivpn_backup_${timestamp}.tar.gz"
    local backup_path="$BACKUP_DIR/$backup_file"
    local github_url=""
    
    echo -e "${YELLOW}Membuat backup...${NC}"
    
    # Buat backup lokal
    tar -czf "$backup_path" \
        "$CONFIG_FILE" \
        "$USER_DB" \
        "$BACKUP_CONFIG" \
        "$DOMAIN_FILE" \
        "/etc/zivpn/zivpn.crt" \
        "/etc/zivpn/zivpn.key" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Backup lokal berhasil: $backup_file${NC}"
        
        # Upload ke GitHub jika diaktifkan
        if [ "$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null)" = "true" ]; then
            github_url=$(upload_to_github "$backup_path" "$backup_file")
        fi
        
        # Hapus backup lokal lama
        cleanup_old_backups
        
        # Update last backup time
        jq --arg time "$(date +"%Y-%m-%d %H:%M:%S")" '.backup.last_backup = $time' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG"
        
        # Kirim notifikasi ke Telegram
        send_backup_notification "$backup_file" "$github_url"
        
        return 0
    else
        echo -e "${RED}❌ Gagal membuat backup${NC}"
        return 1
    fi
}

# Fungsi untuk upload ke GitHub
upload_to_github() {
    local file_path=$1
    local filename=$2
    local github_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null)
    local github_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null)
    local github_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null)
    local backup_dir=$(jq -r '.github.backup_dir' "$BACKUP_CONFIG" 2>/dev/null)
    
    echo -e "${YELLOW}Mengupload ke GitHub...${NC}"
    
    # Cek apakah GitHub diaktifkan
    if [ "$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null)" != "true" ]; then
        echo -e "${YELLOW}GitHub backup tidak diaktifkan${NC}"
        return 1
    fi
    
    # Cek kredensial GitHub
    if [ -z "$github_token" ] || [ "$github_token" = "null" ] || \
       [ -z "$github_username" ] || [ "$github_username" = "null" ] || \
       [ -z "$github_repo" ] || [ "$github_repo" = "null" ]; then
        echo -e "${RED}❌ Kredensial GitHub belum lengkap${NC}"
        return 1
    fi
    
    # Encode file ke base64
    echo -e "${YELLOW}Encoding file...${NC}"
    local content_base64=$(base64 -w 0 "$file_path")
    
    if [ -z "$content_base64" ]; then
        echo -e "${RED}❌ Gagal encoding file${NC}"
        return 1
    fi
    
    # Buat payload JSON
    local payload=$(cat << EOF
{
    "message": "ZIVPN Backup $(date '+%Y-%m-%d %H:%M:%S')",
    "content": "$content_base64",
    "branch": "main"
}
EOF
    )
    
    # URL untuk upload file
    local upload_url="https://api.github.com/repos/$github_username/$github_repo/contents/$backup_dir/$filename"
    
    echo -e "${YELLOW}Mengupload ke $upload_url...${NC}"
    
    # Upload file menggunakan curl
    response=$(curl -s -X PUT "$upload_url" \
        -H "Authorization: token $github_token" \
        -H "Accept: application/vnd.github.v3+json" \
        -d "$payload")
    
    # Cek response
    if echo "$response" | grep -q '"content"'; then
        echo -e "${GREEN}✓ Upload ke GitHub berhasil${NC}"
        
        # Dapatkan download URL
        local download_url=$(echo "$response" | jq -r '.content.download_url' 2>/dev/null)
        if [ ! -z "$download_url" ] && [ "$download_url" != "null" ]; then
            echo -e "${CYAN}Download URL: ${GREEN}$download_url${NC}"
            
            # Simpan URL ke file untuk restore nanti
            local url_file="$BACKUP_DIR/${filename}.url"
            echo "$download_url" > "$url_file"
            
            # Kembalikan URL untuk digunakan di fungsi lain
            echo "$download_url"
            return 0
        fi
        return 0
    else
        echo -e "${RED}❌ Gagal upload ke GitHub${NC}"
        echo -e "${YELLOW}Response: $response${NC}"
        return 1
    fi
}

# Fungsi untuk download dari GitHub
download_from_github() {
    local backup_url=$1
    local filename=$(basename "$backup_url")
    local save_path="$BACKUP_DIR/$filename"
    
    echo -e "${YELLOW}Mendownload $filename...${NC}"
    
    # Download menggunakan curl
    if curl -s -L -o "$save_path" "$backup_url"; then
        echo -e "${GREEN}✓ Download berhasil: $filename${NC}"
        return 0
    else
        echo -e "${RED}❌ Gagal mendownload file${NC}"
        return 1
    fi
}

# Fungsi untuk hapus backup lama
cleanup_old_backups() {
    local keep_days=$(jq -r '.backup.keep_local_backups' "$BACKUP_CONFIG")
    
    if [ -z "$keep_days" ] || [ "$keep_days" = "null" ]; then
        keep_days=7
    fi
    
    echo -e "${YELLOW}Membersihkan backup lama (lebih dari $keep_days hari)...${NC}"
    
    # Hapus file backup yang lebih tua dari keep_days
    find "$BACKUP_DIR" -name "zivpn_backup_*.tar.gz" -mtime +$keep_days -delete 2>/dev/null
    find "$BACKUP_DIR" -name "zivpn_backup_*.tar.gz.url" -mtime +$keep_days -delete 2>/dev/null
    
    echo -e "${GREEN}✓ Backup lama telah dibersihkan${NC}"
}

# Fungsi untuk restore backup
restore_backup() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}🔄 RESTORE BACKUP${NC}\n"
        
        echo -e "${CYAN}Pilih sumber restore:${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}1. ${NC}Dari Backup Lokal"
        echo -e "${GREEN}2. ${NC}Dari GitHub URL"
        echo -e "${GREEN}3. ${NC}Kembali ke Menu Utama"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-3]: "${NC})" source_choice
        
        case $source_choice in
            1)
                restore_from_local
                ;;
            2)
                restore_from_github_url
                ;;
            3)
                return
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Fungsi untuk restore dari backup lokal
restore_from_local() {
    show_header
    echo -e "${CYAN}${BOLD}📂 RESTORE DARI BACKUP LOKAL${NC}\n"
    
    # Cek apakah ada backup lokal
    local backup_files=("$BACKUP_DIR"/zivpn_backup_*.tar.gz)
    
    if [ ${#backup_files[@]} -eq 0 ] || [ ! -f "${backup_files[0]}" ]; then
        echo -e "${YELLOW}Tidak ada backup lokal ditemukan${NC}"
        
        echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
        read
        return
    fi
    
    echo -e "${CYAN}Pilih backup untuk restore:${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    local i=1
    for file in "${backup_files[@]}"; do
        if [ -f "$file" ]; then
            local filename=$(basename "$file")
            local filedate=$(echo "$filename" | grep -o '[0-9]\{8\}_[0-9]\{6\}' || echo "")
            if [ ! -z "$filedate" ]; then
                local date_formatted=$(echo "$filedate" | sed 's/\(....\)\(..\)\(..\)_\(..\)\(..\)\(..\)/\1-\2-\3 \4:\5:\6/')
                echo -e "${GREEN}$i. ${NC}$filename (${date_formatted})"
            else
                echo -e "${GREEN}$i. ${NC}$filename"
            fi
            ((i++))
        fi
    done
    
    if [ $i -eq 1 ]; then
        echo -e "${YELLOW}Tidak ada backup yang valid${NC}"
        echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
        read
        return
    fi
    
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    read -p "$(echo -e ${YELLOW}"Pilih backup [1-$((i-1))]: "${NC})" choice
    
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le $((i-1)) ]; then
        local selected_file="${backup_files[$((choice-1))]}"
        perform_restore "$selected_file"
    else
        echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
        sleep 1
    fi
}

# Fungsi untuk restore dari GitHub URL
restore_from_github_url() {
    show_header
    echo -e "${CYAN}${BOLD}🌐 RESTORE DARI GITHUB URL${NC}\n"
    
    echo -e "${YELLOW}Masukkan URL backup dari GitHub:${NC}"
    echo -e "${CYAN}Contoh: https://raw.githubusercontent.com/rahmatstorevpn/project/main/zivpn_backups/zivpn_backup_20241215_120000.tar.gz${NC}"
    echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
    
    read -p "$(echo -e ${YELLOW}"URL: "${NC})" backup_url
    
    if [ -z "$backup_url" ]; then
        echo -e "${RED}❌ URL tidak boleh kosong${NC}"
        sleep 2
        return
    fi
    
    # Validasi URL
    if [[ ! "$backup_url" =~ ^https://.*\.tar\.gz$ ]]; then
        echo -e "${RED}❌ URL tidak valid. Harus berakhir dengan .tar.gz${NC}"
        sleep 2
        return
    fi
    
    # Download file dari URL
    local filename=$(basename "$backup_url")
    local temp_file="$BACKUP_DIR/temp_$filename"
    
    echo -e "${YELLOW}Mendownload backup dari:${NC}"
    echo -e "${CYAN}$backup_url${NC}"
    echo -e "${YELLOW}Mendownload...${NC}"
    
    if curl -s -L -o "$temp_file" "$backup_url"; then
        if [ -f "$temp_file" ] && [ -s "$temp_file" ]; then
            echo -e "${GREEN}✓ Download berhasil${NC}"
            echo -e "${CYAN}Size: $(du -h "$temp_file" | cut -f1)${NC}"
            
            # Simpan URL untuk referensi
            local url_file="$BACKUP_DIR/${filename}.source"
            echo "GitHub URL: $backup_url" > "$url_file"
            echo "Downloaded: $(date)" >> "$url_file"
            
            perform_restore "$temp_file"
        else
            echo -e "${RED}❌ File download kosong atau corrupt${NC}"
        fi
    else
        echo -e "${RED}❌ Gagal mendownload dari URL${NC}"
    fi
    
    # Hapus file temp jika masih ada
    [ -f "$temp_file" ] && rm -f "$temp_file"
}

# Fungsi untuk kirim notifikasi restore ke Telegram
send_restore_notification() {
    local backup_file=$1
    local source=$2
    
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        
        local message="🔄 RESTORE BERHASIL\n\n"
        message+="🖥️  Server: $server_ip\n"
        message+="📁 File: $backup_file\n"
        message+="📂 Sumber: $source\n"
        message+="🕐 Waktu: $(date)\n"
        message+="👥 Total User: $(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")\n"
        
        message+="\n✅ Restore selesai, service telah direstart"
        
        send_telegram_notification "$message"
    fi
}

# Fungsi untuk kirim notifikasi backup ke Telegram
send_backup_notification() {
    local backup_file=$1
    local github_url=$2
    
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        local backup_size=$(du -h "$BACKUP_DIR/$backup_file" 2>/dev/null | cut -f1 || echo "Unknown")
        local total_users=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        local backup_config=$(jq -r '.backup.keep_local_backups' "$BACKUP_CONFIG" 2>/dev/null || echo "7")
        
        local message="📦 BACKUP BERHASIL DIBUAT\n\n"
        message+="🖥️  Server: $server_ip\n"
        message+="📁 File: $backup_file\n"
        message+="📊 Size: $backup_size\n"
        message+="👥 Total User: $total_users\n"
        message+="🕐 Waktu: $(date)\n"
        message+="💾 Keep Local: $backup_config hari\n"
        
        # Tambahkan URL GitHub jika ada
        if [ ! -z "$github_url" ] && [ "$github_url" != "null" ]; then
            message+="\n🌐 GitHub URL:\n"
            message+="$github_url\n"
            message+="\n📥 Download via:\n"
            message+="curl -L \"$github_url\" -o backup.tar.gz\n"
        fi
        
        message+="\n✅ Backup selesai dan aman tersimpan"
        
        send_telegram_notification "$message"
    fi
}

# Fungsi untuk melakukan restore
perform_restore() {
    local backup_file=$1
    local filename=$(basename "$backup_file")
    local source_type="Lokal"
    
    # Cek apakah dari GitHub URL
    if [[ "$backup_file" == *"temp_"* ]]; then
        source_type="GitHub URL"
    fi
    
    echo -e "\n${YELLOW}⚠️  Konfirmasi Restore${NC}"
    echo -e "${BOLD}────────────────────────────────────${NC}"
    echo -e "${RED}File yang akan di-restore:${NC}"
    echo -e "${RED}$filename${NC}"
    echo -e "${RED}Sumber: $source_type${NC}"
    echo -e "${BOLD}────────────────────────────────────${NC}"
    echo -e "${YELLOW}PERINGATAN: Restore akan mengganti semua konfigurasi saat ini!${NC}"
    
    read -p "$(echo -e ${YELLOW}"Lanjutkan? (y/n): "${NC})" confirm
    
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Restore dibatalkan${NC}"
        sleep 1
        return
    fi
    
    # Backup konfigurasi saat ini dulu
    local current_backup="$BACKUP_DIR/current_before_restore_$(date +"%Y%m%d_%H%M%S").tar.gz"
    echo -e "${YELLOW}Membuat backup konfigurasi saat ini...${NC}"
    tar -czf "$current_backup" \
        "$CONFIG_FILE" \
        "$USER_DB" \
        "$BACKUP_CONFIG" \
        "$DOMAIN_FILE" \
        "/etc/zivpn/zivpn.crt" \
        "/etc/zivpn/zivpn.key" 2>/dev/null
    
    # Ekstrak backup yang dipilih
    echo -e "${YELLOW}Melakukan restore...${NC}"
    tar -xzf "$backup_file" -C /
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Restore berhasil${NC}"
        
        # Restart service
        restart_service
        
        # Kirim notifikasi
        send_restore_notification "$filename" "$source_type"
        
        echo -e "\n${GREEN}Service telah direstart dengan konfigurasi baru${NC}"
    else
        echo -e "${RED}❌ Gagal melakukan restore${NC}"
        
        # Rollback jika gagal
        echo -e "${YELLOW}Melakukan rollback...${NC}"
        tar -xzf "$current_backup" -C /
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ Rollback berhasil${NC}"
        else
            echo -e "${RED}❌ Gagal rollback${NC}"
        fi
    fi
    
    echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
    read
}

# Fungsi untuk mengatur konfigurasi backup
configure_backup() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}⚙️  KONFIGURASI BACKUP${NC}\n"
        
        local backup_enabled=$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local auto_backup=$(jq -r '.backup.auto_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local github_enabled=$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local backup_interval=$(jq -r '.backup.backup_interval' "$BACKUP_CONFIG" 2>/dev/null || echo "daily")
        local keep_backups=$(jq -r '.backup.keep_local_backups' "$BACKUP_CONFIG" 2>/dev/null || echo "7")
        local telegram_enabled=$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local github_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null || echo "")
        local github_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null || echo "")
        local github_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null || echo "")
        
        echo -e "${BG_PURPLE}${BOLD}   SETTING BACKUP   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}1. Backup System      : ${GREEN}$backup_enabled${NC}"
        echo -e "${CYAN}2. Auto Backup        : ${GREEN}$auto_backup${NC}"
        echo -e "${CYAN}3. GitHub Backup      : ${GREEN}$github_enabled${NC}"
        echo -e "${CYAN}4. Interval Backup    : ${GREEN}$backup_interval${NC}"
        echo -e "${CYAN}5. Keep Local Backups : ${GREEN}$keep_backups hari${NC}"
        echo -e "${CYAN}6. Telegram Notify    : ${GREEN}$telegram_enabled${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}7. Konfigurasi GitHub${NC}"
        echo -e "${CYAN}8. Konfigurasi Telegram${NC}"
        echo -e "${CYAN}9. Test Backup${NC}"
        echo -e "${CYAN}10. Test Telegram${NC}"
        echo -e "${CYAN}11. Kembali ke Menu Utama${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-11]: "${NC})" choice
        
        case $choice in
            1)
                toggle_setting "backup.enabled"
                ;;
            2)
                toggle_setting "backup.auto_backup"
                ;;
            3)
                toggle_setting "backup.github_enabled"
                ;;
            4)
                set_backup_interval
                ;;
            5)
                set_keep_backups
                ;;
            6)
                toggle_setting "telegram.enabled"
                ;;
            7)
                configure_github
                ;;
            8)
                configure_telegram
                ;;
            9)
                create_backup
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            10)
                test_telegram
                ;;
            11)
                break
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Fungsi untuk toggle setting
toggle_setting() {
    local setting=$1
    local current_value=$(jq -r ".$setting" "$BACKUP_CONFIG" 2>/dev/null)
    
    if [ "$current_value" = "true" ]; then
        jq ".$setting = false" "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
        echo -e "${YELLOW}✓ Setting dinonaktifkan${NC}"
    else
        jq ".$setting = true" "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
        echo -e "${GREEN}✓ Setting diaktifkan${NC}"
    fi
    
    sleep 1
}

# Fungsi untuk set backup interval
set_backup_interval() {
    echo -e "\n${CYAN}Pilih interval backup:${NC}"
    echo -e "${GREEN}1. ${NC}Daily"
    echo -e "${GREEN}2. ${NC}Weekly"
    echo -e "${GREEN}3. ${NC}Monthly"
    
    read -p "$(echo -e ${YELLOW}"Pilih [1-3]: "${NC})" interval_choice
    
    case $interval_choice in
        1) interval="daily" ;;
        2) interval="weekly" ;;
        3) interval="monthly" ;;
        *) 
            echo -e "${RED}❌ Pilihan tidak valid!${NC}"
            sleep 1
            return
            ;;
    esac
    
    jq --arg int "$interval" '.backup.backup_interval = $int' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    echo -e "${GREEN}✓ Interval backup diatur ke $interval${NC}"
    sleep 1
}

# Fungsi untuk set keep backups
set_keep_backups() {
    read -p "$(echo -e ${YELLOW}"Masukkan jumlah hari menyimpan backup lokal [7-30]: "${NC})" days
    
    if [[ "$days" =~ ^[0-9]+$ ]] && [ "$days" -ge 7 ] && [ "$days" -le 30 ]; then
        jq --argjson days "$days" '.backup.keep_local_backups = $days' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
        echo -e "${GREEN}✓ Backup lokal akan disimpan selama $days hari${NC}"
    else
        echo -e "${RED}❌ Masukkan angka antara 7-30${NC}"
    fi
    
    sleep 1
}

# Fungsi untuk konfigurasi GitHub
configure_github() {
    echo -e "\n${CYAN}Konfigurasi GitHub:${NC}"
    
    local current_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null)
    local current_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null)
    local current_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null)
    local current_dir=$(jq -r '.github.backup_dir' "$BACKUP_CONFIG" 2>/dev/null)
    
    echo -e "${YELLOW}Token saat ini: ${GREEN}$current_token${NC}"
    read -p "$(echo -e ${YELLOW}"GitHub Token (tekan Enter untuk tidak mengubah): "${NC})" new_token
    
    echo -e "${YELLOW}Username saat ini: ${GREEN}$current_username${NC}"
    read -p "$(echo -e ${YELLOW}"GitHub Username (tekan Enter untuk tidak mengubah): "${NC})" new_username
    
    echo -e "${YELLOW}Repository saat ini: ${GREEN}$current_repo${NC}"
    read -p "$(echo -e ${YELLOW}"Repository Name (tekan Enter untuk tidak mengubah): "${NC})" new_repo
    
    echo -e "${YELLOW}Backup directory saat ini: ${GREEN}$current_dir${NC}"
    read -p "$(echo -e ${YELLOW}"Backup Directory (tekan Enter untuk tidak mengubah): "${NC})" new_dir
    
    # Update konfigurasi
    if [ ! -z "$new_token" ]; then
        jq --arg token "$new_token" '.github.token = $token' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_username" ]; then
        jq --arg username "$new_username" '.github.username = $username' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_repo" ]; then
        jq --arg repo "$new_repo" '.github.repo = $repo' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_dir" ]; then
        jq --arg dir "$new_dir" '.github.backup_dir = $dir' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    echo -e "${GREEN}✓ Konfigurasi GitHub diperbarui${NC}"
    
    # Test koneksi GitHub
    echo -e "${YELLOW}Menguji koneksi GitHub...${NC}"
    if test_github_connection; then
        echo -e "${GREEN}✓ Koneksi GitHub berhasil${NC}"
    else
        echo -e "${RED}❌ Gagal terhubung ke GitHub${NC}"
    fi
    
    sleep 2
}

# Fungsi untuk test koneksi GitHub
test_github_connection() {
    local github_token=$(jq -r '.github.token' "$BACKUP_CONFIG" 2>/dev/null)
    local github_username=$(jq -r '.github.username' "$BACKUP_CONFIG" 2>/dev/null)
    local github_repo=$(jq -r '.github.repo' "$BACKUP_CONFIG" 2>/dev/null)
    
    if [ -z "$github_token" ] || [ "$github_token" = "null" ] || \
       [ -z "$github_username" ] || [ "$github_username" = "null" ] || \
       [ -z "$github_repo" ] || [ "$github_repo" = "null" ]; then
        return 1
    fi
    
    # Test API GitHub
    response=$(curl -s -H "Authorization: token $github_token" \
        "https://api.github.com/repos/$github_username/$github_repo" 2>/dev/null)
    
    if echo "$response" | grep -q '"full_name"'; then
        return 0
    else
        return 1
    fi
}

# Fungsi untuk konfigurasi Telegram
configure_telegram() {
    echo -e "\n${CYAN}Konfigurasi Telegram:${NC}"
    
    local current_token=$(jq -r '.telegram.bot_token' "$BACKUP_CONFIG" 2>/dev/null)
    local current_chat_id=$(jq -r '.telegram.chat_id' "$BACKUP_CONFIG" 2>/dev/null)
    
    echo -e "${YELLOW}Bot Token saat ini: ${GREEN}$current_token${NC}"
    read -p "$(echo -e ${YELLOW}"Bot Token (tekan Enter untuk tidak mengubah): "${NC})" new_token
    
    echo -e "${YELLOW}Chat ID saat ini: ${GREEN}$current_chat_id${NC}"
    read -p "$(echo -e ${YELLOW}"Chat ID (tekan Enter untuk tidak mengubah): "${NC})" new_chat_id
    
    # Update konfigurasi
    if [ ! -z "$new_token" ]; then
        jq --arg token "$new_token" '.telegram.bot_token = $token' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    if [ ! -z "$new_chat_id" ]; then
        jq --arg chat "$new_chat_id" '.telegram.chat_id = $chat' "$BACKUP_CONFIG" > tmp.json && mv tmp.json "$BACKUP_CONFIG" 2>/dev/null
    fi
    
    echo -e "${GREEN}✓ Konfigurasi Telegram diperbarui${NC}"
    
    # Test koneksi Telegram
    echo -e "${YELLOW}Menguji koneksi Telegram...${NC}"
    if send_telegram_notification "✅ Bot Telegram berhasil dikonfigurasi!\n\nWaktu: $(date)\nServer: $(hostname)"; then
        echo -e "${GREEN}✓ Test notifikasi berhasil dikirim${NC}"
    else
        echo -e "${RED}❌ Gagal mengirim notifikasi${NC}"
    fi
    
    sleep 2
}

# Fungsi untuk test Telegram
test_telegram() {
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        echo -e "${YELLOW}Mengirim test notifikasi...${NC}"
        
        if send_telegram_notification "🔔 Test Notifikasi dari ZIVPN Manager\n\nWaktu: $(date)\nServer: $(hostname)\nIP: $(get_server_ip)\n\n✅ Bot Telegram berfungsi dengan baik!"; then
            echo -e "${GREEN}✓ Test notifikasi berhasil dikirim${NC}"
        else
            echo -e "${RED}❌ Gagal mengirim notifikasi${NC}"
        fi
    else
        echo -e "${YELLOW}Telegram belum dikonfigurasi${NC}"
    fi
    
    sleep 2
}

# Fungsi untuk auto backup
auto_backup() {
    local last_backup=$(jq -r '.backup.last_backup' "$BACKUP_CONFIG" 2>/dev/null)
    local interval=$(jq -r '.backup.backup_interval' "$BACKUP_CONFIG" 2>/dev/null || echo "daily")
    
    if [ "$last_backup" = "null" ] || [ -z "$last_backup" ]; then
        # Belum pernah backup, buat backup sekarang
        create_backup
        return
    fi
    
    # Konversi last_backup ke timestamp
    local last_timestamp=$(date -d "$last_backup" +%s 2>/dev/null)
    if [ $? -ne 0 ]; then
        # Format tanggal tidak valid, buat backup baru
        create_backup
        return
    fi
    
    local current_timestamp=$(date +%s)
    local diff_seconds=$((current_timestamp - last_timestamp))
    
    # Tentukan interval dalam detik
    case $interval in
        "daily")
            local interval_seconds=86400  # 1 hari
            ;;
        "weekly")
            local interval_seconds=604800  # 7 hari
            ;;
        "monthly")
            local interval_seconds=2592000  # 30 hari
            ;;
        *)
            local interval_seconds=86400
            ;;
    esac
    
    # Cek apakah sudah waktunya backup
    if [ $diff_seconds -ge $interval_seconds ]; then
        echo -e "${YELLOW}🔄 Menjalankan auto backup...${NC}"
        create_backup
    fi
}

# Fungsi untuk kirim notifikasi ketika user baru dibuat
send_new_user_notification() {
    local username=$1
    local password=$2
    local expiry=$3
    local period=$4
    
    if [ "$(jq -r '.telegram.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.telegram.notify_on_new_user' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        
        local server_ip=$(get_server_ip)
        local domain=$(get_domain)
        local message="👤 USER BARU DITAMBAHKAN\n\n"
        message+="📱 Username: $username\n"
        message+="🔑 Password: $password\n"
        message+="📅 Masa Aktif: $period\n"
        
        if [ "$expiry" != "unlimited" ]; then
            message+="⏰ Expired: $expiry\n"
        fi
        
        if [ ! -z "$domain" ]; then
            message+="\n🌐 Domain: $domain\n"
        fi
        message+="🖥️  Server: $server_ip\n"
        message+="🔌 Port: 5667\n"
        message+="🕐 Waktu: $(date)\n\n"
        message+="✅ User berhasil ditambahkan ke sistem"
        
        send_telegram_notification "$message"
    fi
}

# ==============================
# UPDATE MAIN MENU
# ==============================

# Fungsi untuk menu backup & restore
backup_restore_menu() {
    while true; do
        show_header
        echo -e "${CYAN}${BOLD}💾 BACKUP & RESTORE${NC}\n"
        
        local last_backup=$(jq -r '.backup.last_backup' "$BACKUP_CONFIG" 2>/dev/null)
        if [ "$last_backup" = "null" ] || [ -z "$last_backup" ]; then
            last_backup="Belum pernah"
        fi
        
        local backup_enabled=$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        local github_enabled=$(jq -r '.backup.github_enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")
        
        echo -e "${BG_PURPLE}${BOLD}   INFORMASI BACKUP   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}Last Backup     : ${GREEN}$last_backup${NC}"
        echo -e "${CYAN}Backup Enabled  : ${GREEN}$backup_enabled${NC}"
        echo -e "${CYAN}GitHub Backup   : ${GREEN}$github_enabled${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}1. ${NC}Buat Backup Sekarang"
        echo -e "${BLUE}2. ${NC}Restore dari Backup"
        echo -e "${YELLOW}3. ${NC}Lihat Backup Lokal"
        echo -e "${PURPLE}4. ${NC}Kembali ke Menu Utama"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${YELLOW}"Pilih [1-4]: "${NC})" choice
        
        case $choice in
            1)
                create_backup
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            2)
                restore_backup
                ;;
            3)
                list_local_backups
                ;;
            4)
                break
                ;;
            *)
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Fungsi untuk list backup lokal
list_local_backups() {
    show_header
    echo -e "${CYAN}${BOLD}📂 BACKUP LOKAL${NC}\n"
    
    # Buat array backup files
    local backup_files=()
    while IFS= read -r -d $'\0' file; do
        backup_files+=("$file")
    done < <(find "$BACKUP_DIR" -name "zivpn_backup_*.tar.gz" -print0 2>/dev/null)
    
    if [ ${#backup_files[@]} -eq 0 ]; then
        echo -e "${YELLOW}Tidak ada backup lokal${NC}"
    else
        echo -e "${BG_PURPLE}${BOLD}   DAFTAR BACKUP   ${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════${NC}"
        
        local total_size=0
        for file in "${backup_files[@]}"; do
            if [ -f "$file" ]; then
                local filename=$(basename "$file")
                local size=$(du -h "$file" 2>/dev/null | cut -f1 || echo "0B")
                local filedate=$(echo "$filename" | grep -o '[0-9]\{8\}_[0-9]\{6\}' || echo "")
                local date_formatted=""
                if [ ! -z "$filedate" ]; then
                    date_formatted=$(echo "$filedate" | sed 's/\(....\)\(..\)\(..\)_\(..\)\(..\)\(..\)/\1-\2-\3 \4:\5:\6/')
                fi
                
                echo -e "${GREEN}📁 ${NC}$filename"
                echo -e "   📅 $date_formatted | 📊 $size"
                echo -e "${BOLD}────────────────────────────────────────────────────────${NC}"
                
                # Hitung total size
                local size_bytes=$(stat -c%s "$file" 2>/dev/null || echo "0")
                total_size=$((total_size + size_bytes))
            fi
        done
        
        echo -e "${CYAN}Total Backup : ${GREEN}${#backup_files[@]} files${NC}"
        if [ $total_size -gt 0 ]; then
            echo -e "${CYAN}Total Size   : ${GREEN}$(echo "scale=2; $total_size/1024/1024" | bc) MB${NC}"
        else
            echo -e "${CYAN}Total Size   : ${GREEN}0 MB${NC}"
        fi
    fi
    
    echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
    read
}

# Update main_menu() untuk tambah menu backup
main_menu() {
    # Install dependencies
    install_dependencies
    
    # Inisialisasi database
    init_user_db
    ensure_config_structure
    
    # Inisialisasi konfigurasi backup
    init_backup_config
    
    # Inisialisasi domain
    init_domain
    
    # Jalankan auto cleanup saat start
    auto_cleanup_expired
    
    # Jalankan auto backup jika waktunya
    if [ "$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ] && \
       [ "$(jq -r '.backup.auto_backup' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
        auto_backup
    fi
    
    while true; do
        show_header
        
        # Cek status service
        if systemctl is-active --quiet $SERVICE 2>/dev/null; then
            status="${GREEN}● RUNNING${NC}"
        else
            status="${RED}● STOPPED${NC}"
        fi
        
        # Hitung jumlah user
        user_count=$(jq '.users | length' "$USER_DB" 2>/dev/null || echo "0")
        
        # Ambil IP server dan domain
        SERVER_IP=$(get_server_ip)
        DOMAIN=$(get_domain)
        
        # Hitung user aktif vs expired
        active_count=0
        expired_count=0
        trial_count=0
        
        jq -r '.users | keys[]' "$USER_DB" 2>/dev/null | while read username; do
            user_type=$(jq -r ".users.\"$username\".user_type" "$USER_DB" 2>/dev/null)
            status_check=$(check_expiry "$username")
            
            if [ "$user_type" = "trial" ]; then
                ((trial_count++))
            fi
            
            if [ "$status_check" = "expired" ] || [ "$status_check" = "trial_expired" ]; then
                ((expired_count++))
            else
                ((active_count++))
            fi
        done
        
        # Cek status backup
        if [ "$(jq -r '.backup.enabled' "$BACKUP_CONFIG" 2>/dev/null || echo "false")" = "true" ]; then
            backup_status="${GREEN}● AKTIF${NC}"
        else
            backup_status="${RED}● NONAKTIF${NC}"
        fi
        
        echo -e "${CYAN}${BOLD}📱 MENU UTAMA ZIVPN BISNIS${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
        echo -e "${CYAN}Status Service  :${NC} $status"
        echo -e "${CYAN}Status Backup   :${NC} $backup_status"
        echo -e "${CYAN}IP Server       :${NC} ${GREEN}${BOLD}$SERVER_IP${NC}"
        if [ ! -z "$DOMAIN" ] && [ "$(jq -r '.auto_display // true' "$DOMAIN_FILE" 2>/dev/null)" = "true" ]; then
            echo -e "${CYAN}Domain         :${NC} ${GREEN}${BOLD}$DOMAIN${NC}"
        fi
        echo -e "${CYAN}Port            :${NC} ${GREEN}${BOLD}5667${NC}"
        echo -e "${CYAN}Total User      :${NC} ${YELLOW}${BOLD}$user_count${NC}"
        echo -e "${CYAN}User Aktif      :${NC} ${GREEN}${BOLD}$active_count${NC}"
        echo -e "${CYAN}User Expired    :${NC} ${RED}${BOLD}$expired_count${NC}"
        echo -e "${CYAN}Trial User      :${NC} ${CYAN}${BOLD}$trial_count${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
        echo -e "${GREEN}${BOLD}1. ${NC}${BOLD}➕ Tambah User Baru${NC}"
        echo -e "${CYAN}${BOLD}2. ${NC}${BOLD}🎫 Buat Trial User (35 menit)${NC}"
        echo -e "${RED}${BOLD}3. ${NC}${BOLD}🗑️  Hapus User${NC}"
        echo -e "${BLUE}${BOLD}4. ${NC}${BOLD}📋 Lihat Semua User${NC}"
        echo -e "${GREEN}${BOLD}5. ${NC}${BOLD}🔄 Renew User${NC}"
        echo -e "${YELLOW}${BOLD}6. ${NC}${BOLD}⚙️  Konfigurasi Domain${NC}"
        echo -e "${PURPLE}${BOLD}7. ${NC}${BOLD}🧹 Cleanup Trial Users${NC}"
        echo -e "${YELLOW}${BOLD}8. ${NC}${BOLD}🔄 Restart Service${NC}"
        echo -e "${GREEN}${BOLD}9. ${NC}${BOLD}💾 Backup & Restore${NC}"
        echo -e "${CYAN}${BOLD}10. ${NC}${BOLD}⚙️  Konfigurasi Backup${NC}"
        echo -e "${RED}${BOLD}11. ${NC}${BOLD}🚪 Keluar${NC}"
        echo -e "${BOLD}════════════════════════════════════════════════════════════${NC}"
        
        read -p "$(echo -e ${PURPLE}"Pilih menu [1-11]: "${NC})" choice

        case $choice in
            1) add_user ;;
            2) 
                create_trial_user
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            3) delete_user ;;
            4) list_users ;;
            5) renew_user ;;
            6) configure_domain ;;
            7) cleanup_trial_users ;;
            8) 
                show_header
                echo -e "${CYAN}${BOLD}🔄 RESTART SERVICE ZIVPN${NC}\n"
                restart_service
                echo -e "\n${YELLOW}Tekan Enter untuk kembali...${NC}"
                read
                ;;
            9) 
                backup_restore_menu
                ;;
            10)
                configure_backup
                ;;
            11) 
                show_header
                echo -e "\n${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}"
                echo -e "${GREEN}${BOLD}                    TERIMA KASIH!                            ${NC}"
                echo -e "${GREEN}${BOLD}            Semoga bisnis lancar! 💰                         ${NC}"
                echo -e "${GREEN}${BOLD}════════════════════════════════════════════════════════════${NC}\n"
                exit 0 
                ;;
            *) 
                echo -e "\n${RED}❌ Pilihan tidak valid!${NC}"
                sleep 1
                ;;
        esac
    done
}

# Trap untuk exit bersih
trap 'echo -e "\n${YELLOW}Script dihentikan${NC}"; exit 1' INT TERM

# Jalankan main menu
main_menu